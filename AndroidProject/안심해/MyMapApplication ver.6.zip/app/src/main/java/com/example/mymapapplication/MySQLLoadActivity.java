package com.example.mymapapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.json.JSONException;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MySQLLoadActivity extends AppCompatActivity {
    private static final String TAG = "test";
    static RequestQueue requestQueue;
    SQLiteDatabase database;
    DatabaseHelper dataHelper;
    String tableName,loc;
    final String ip="10.100.202.81";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_s_q_l_load);

        Intent intent = getIntent();

        loc=intent.getExtras().getString("loc");
        tableName=intent.getExtras().getString("tableName");


        if(requestQueue==null){
            requestQueue= Volley.newRequestQueue(getApplicationContext());
        }
        SettingRequest(loc);

    }
    public void SettingRequest(String Loc){
        //String ip= context.getString(R.string.MyIp);

        String url="http://"+ip+":8090/board/policeLocation?Location="+Loc;
        Log.i(TAG, url);
        StringRequest request=new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        println("policeLocation 응답 ->" + response);

                        try {
                            if(response.equals("[]")) {
                            }else {
                                dateResponse(response,tableName);
                            }

                        } catch (JSONException | ParseException e) {
                            e.printStackTrace();
                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        println("에러 ->" + error.getMessage());
                    }
                }
        ){
            @Override //response를 UTF8로 변경해주는 소스코드
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                try {
                    String utf8String = new String(response.data, "UTF-8");
                    return Response.success(utf8String, HttpHeaderParser.parseCacheHeaders(response));
                } catch (UnsupportedEncodingException e) {
                    // log error
                    return Response.error(new ParseError(e));
                } catch (Exception e) {
                    // log error
                    return Response.error(new ParseError(e));
                }
            }
            protected Map<String,String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String,String>();
                return params;
            }
        };

        request.setShouldCache(false);
        requestQueue.add(request);
        println("요청보냄");
    }
    public void SettingRequest2(String Loc){
        //String ip= context.getString(R.string.MyIp);

        String url="http://"+ip+":8090/board/bellLocation?Location="+Loc;
        Log.i(TAG, url);
        StringRequest request=new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        println("bellLocation 응답 ->" + response);

                        try {
                            if(response.equals("[]")) {
                            }else {
                                dateResponse2(response,"bellLocation");
                            }

                        } catch (JSONException | ParseException e) {
                            e.printStackTrace();
                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        println("에러 ->" + error.getMessage());
                    }
                }
        ){
            @Override //response를 UTF8로 변경해주는 소스코드
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                try {
                    String utf8String = new String(response.data, "UTF-8");
                    return Response.success(utf8String, HttpHeaderParser.parseCacheHeaders(response));
                } catch (UnsupportedEncodingException e) {
                    // log error
                    return Response.error(new ParseError(e));
                } catch (Exception e) {
                    // log error
                    return Response.error(new ParseError(e));
                }
            }
            protected Map<String,String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String,String>();
                return params;
            }
        };

        request.setShouldCache(false);
        requestQueue.add(request);
        println("요청보냄");
    }
    private void dateResponse(String response,String tableName1) throws JSONException, ParseException {


        Gson gson =new Gson();
        police[] polLoVOS=gson.fromJson(response,police[].class);
        //database.execSQL("DELETE FROM "+tableName1);
       // database.execSQL("DELETE FROM "+tableName1+" WHERE la>0");
        for(int i=0; i<polLoVOS.length;i++){
            dataHelper=new DatabaseHelper(getApplicationContext());
            database=dataHelper.getWritableDatabase();
            ContentValues values =new ContentValues();
            values.put("gucode",polLoVOS[i].getGucode());
            values.put("name",polLoVOS[i].getName());
            values.put("la",polLoVOS[i].getLa());
            values.put("lo",polLoVOS[i].getLo());
            database.insert(tableName1,null,values);
            database.close();
            dataHelper.close();


        }
        SettingRequest2(loc);



    }
    private void dateResponse2(String response,String tableName1) throws JSONException, ParseException {


        Gson gson =new Gson();
        police[] polLoVOS=gson.fromJson(response,police[].class);

       // database.execSQL("DELETE FROM "+tableName1+" WHERE la>0");

        for(int i=0; i<polLoVOS.length;i++){
            dataHelper=new DatabaseHelper(getApplicationContext());
            database=dataHelper.getWritableDatabase();
            ContentValues values =new ContentValues();
            values.put("gucode",polLoVOS[i].getGucode());
            values.put("name",polLoVOS[i].getName());
            values.put("la",polLoVOS[i].getLa());
            values.put("lo",polLoVOS[i].getLo());
            database.insert(tableName1,null,values);
            database.close();
            dataHelper.close();


        }
        finish();



    }
    private void println(String str){
        Log.i("test", "println: "+str+"\n");
    }
}