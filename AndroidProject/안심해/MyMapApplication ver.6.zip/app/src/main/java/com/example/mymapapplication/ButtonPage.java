package com.example.mymapapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;

public class ButtonPage extends AppCompatActivity {
    Boolean state=true;
    Button bellBtn;
    private MediaPlayer background;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //타이틀바 없애기
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_button_page);

        bellBtn =findViewById(R.id.btnBiffStart);

        bellBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(state){
                    //알람음 소리 내기
                    background = MediaPlayer.create(getBaseContext(), R.raw.siren);
                    background.setLooping(true);
                    background.start();
                    //한번 더 누르면 꺼지게 상태 변수 설정
                    state=false;
                    bellBtn.setText("알람끄기!");
                }else {
                    background.stop();
                    background.release();
                    finish();
                }

            }
        });


    }
}