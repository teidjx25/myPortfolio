package com.example.mymapapplication;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class InsertActivity extends AppCompatActivity {
    EditText edName,edMobile;
    Button btnInput,btnCancel;
    String tableName,name,mobile;
    SQLiteDatabase database;
    DatabaseHelper dataHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        edName=findViewById(R.id.etName);
        edMobile=findViewById(R.id.etMobile);
        btnInput=findViewById(R.id.btnInput);
        btnCancel=findViewById(R.id.btnCencel);
        Intent intent = getIntent();
        tableName =intent.getStringExtra("tableName");


        btnInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = edName.getText().toString();
                mobile = edMobile.getText().toString();


                dataHelper=new DatabaseHelper(getApplicationContext());
                database=dataHelper.getWritableDatabase();
                ContentValues values =new ContentValues();
                values.put("name",name);
                values.put("mobile",mobile);
                database.insert(tableName,null,values);
                database.close();
                dataHelper.close();
                finish();
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

}