package com.example.mymapapplication;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, LocationListener {

    private GoogleMap mMap;
    double mLatitude ;
    double mLongitude ;
    String Address,Guname;
    TextView myLocAdress,newstxt;
    //취약지점 좌표 어레이
    ArrayList<Double> la = new ArrayList<Double>();
    ArrayList<Double> lo = new ArrayList<Double>();
    //경찰서 정보 어레이
    ArrayList<String> policename=new ArrayList<String>();
    ArrayList<Double> policela = new ArrayList<Double>();
    ArrayList<Double> policelo = new ArrayList<Double>();

    ArrayList<String> bellname=new ArrayList<String>();
    ArrayList<Double> bellla = new ArrayList<Double>();
    ArrayList<Double> belllo = new ArrayList<Double>();

    DistanceCul dc = new DistanceCul();
    Button newLinkBtn;
    String link;
    static final int SMS_RECEIVE_PERMISSON=1;
    final String TAG= "test";
    DatabaseHelper dataHelper;
    SQLiteDatabase database;
    String tableName,sql;
    //위치정보 객체
    LocationManager lm = null;
    //위치정보 장치 이름
    String provider = null;
    ArrayList<String> PHlist = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        newLinkBtn = findViewById(R.id.newLinkBtn);
        //db생성
        if (database==null){
            dataHelper=new DatabaseHelper(this);
            database=dataHelper.getWritableDatabase();

            tableName ="savingphone";
            sql ="create table if not exists "+tableName+"(" +
                    "_id integer primary key autoincrement," +
                    "name text," +
                    "mobile text)";
            database.execSQL(sql);
            tableName ="PoliceLocation";

            sql ="create table if not exists "+tableName+"(" +
                    "_id integer primary key autoincrement," +
                    "gucode text," +
                    "name text," +
                    "la double," +
                    "lo double)";
            database.execSQL(sql);
            tableName ="BellLocation";
           // database.execSQL("DELETE FROM "+tableName);
            sql ="create table if not exists "+tableName+"(" +
                    "_id integer primary key autoincrement," +
                    "gucode text," +
                    "name text," +
                    "la double," +
                    "lo double)";
            database.execSQL(sql);
        }

        setContentView(R.layout.activity_maps);
        myLocAdress =findViewById(R.id.myLocAdress);
        newstxt =findViewById(R.id.newstxt);

        //뉴스 api를 받아오는 모든 처리
        Thread thread = new ApiNaverNews();
        thread.start();
        //해당 정보를 받아옴
        infomations(thread);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        /**위치정보 객체를 생성한다.*/
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        /** 현재 사용가능한 위치 정보 장치 검색*/
        //위치정보 하드웨어 목록
        Criteria c = new Criteria();
        //최적의 하드웨어 이름을 리턴받는다.
        provider = lm.getBestProvider(c, true);

        // 최적의 값이 없거나, 해당 장치가 사용가능한 상태가 아니라면,
        //모든 장치 리스트에서 사용가능한 항목 얻기
        if (provider == null || !lm.isProviderEnabled(provider)) {
            // 모든 장치 목록
            List<String> list = lm.getAllProviders();

            for (int i = 0; i < list.size(); i++) {
                //장치 이름 하나 얻기
                String temp = list.get(i);

                //사용 가능 여부 검사
                if (lm.isProviderEnabled(temp)) {
                    provider = temp;
                    break;
                }
            }
        }// (end if)위치정보 검색 끝

        /**마지막으로  조회했던 위치 얻기*/
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Location location = lm.getLastKnownLocation(provider);

        if (location == null) {
            Toast.makeText(this, "사용가능한 위치 정보 제공자가 없습니다.", Toast.LENGTH_SHORT).show();
        } else {
            //최종 위치에서 부터 이어서 GPS 시작...
            onLocationChanged(location);

        }
        //권한이 부여되어 있는지 확인
        int permissonCheck= ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        if(permissonCheck == PackageManager.PERMISSION_GRANTED){
            Toast.makeText(getApplicationContext(), "SMS 수신권한 있음", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(getApplicationContext(), "SMS 수신권한 없음", Toast.LENGTH_SHORT).show();
            //권한설정 dialog에서 거부를 누르면
            //ActivityCompat.shouldShowRequestPermissionRationale 메소드의 반환값이 true가 된다.
            //단, 사용자가 "Don't ask again"을 체크한 경우
            //거부하더라도 false를 반환하여, 직접 사용자가 권한을 부여하지 않는 이상, 권한을 요청할 수 없게 된다.
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                //이곳에 권한이 왜 필요한지 설명하는 Toast나 dialog를 띄워준 후, 다시 권한을 요청한다.
                Toast.makeText(getApplicationContext(), "SMS권한이 필요합니다", Toast.LENGTH_SHORT).show();
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_RECEIVE_PERMISSON);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_RECEIVE_PERMISSON);
            }
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        //select 메소드 호출
        readSql("savingphone");

        //해당 구에 경찰서 위치들을 뽑아냄
        if(Guname!=null){
            Intent intent = new Intent(MapsActivity.this, MySQLLoadActivity.class);
            intent.putExtra("loc",Guname);
            intent.putExtra("tableName","PoliceLocation");
            startActivity(intent);
        }
        readSql("PoliceLocation");
        readSql("BellLocation");

        Log.i(TAG, "policename의 크기 "+ policename.size()+"bellname 크기 "+bellname.size());

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        PHlist.clear();
        readSql("savingphone");
        Log.i(TAG, "onRestart: "+PHlist);
    }


    /** 위치가 변했을 경우 호출된다.*/
    @Override
    public void onLocationChanged(Location location) {
        // 위도, 경도
        mLatitude = location.getLatitude();
        mLongitude = location.getLongitude();

/* // String이외의 데이터 형을 String으로 변환하는 메서드
  tv1.setText(String.valueOf(lat));
  // String이외의 데이터 형을 String으로 변화하는 꼼수~!!
  tv2.setText(lng +""); */

        // String이외의 데이터 형을 String으로 변환하는 메서드
        Log.i("test ",String.valueOf(mLatitude) + " / " + String.valueOf(mLongitude));
        // String이외의 데이터 형을 String으로 변화하는 꼼수~!!
        Address=getAddress(mLatitude, mLongitude);

        //나중에 삭제에~~@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        //Address= "대한민국 부산광역시 금정구 부곡3동 중앙대로 1793번길 37";

        String replacegu = Address.replace("대한민국 부산광역시 ","");
        Guname="";

        if(replacegu.indexOf("기장군")==-1){
            for(int i=0; i<=replacegu.indexOf("구"); i++){
                Guname=Guname+replacegu.charAt(i);
            }
        }else {
            Guname="기장군";
        }

        Log.i(TAG, "Guname: "+Guname);


        myLocAdress.setText(Address);

    }
    @Override
    public void onProviderDisabled(String provider) {
        // TODO Auto-generated method stub

    }
    @Override
    public void onProviderEnabled(String provider) {
        // TODO Auto-generated method stub

    }
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // TODO Auto-generated method stub

    }

    /** 위도와 경도 기반으로 주소를 리턴하는 메서드*/
    public String getAddress(double latitude, double longitude){
        Geocoder geocoder = new Geocoder(this, Locale.KOREA);
        List<Address> addresses;
        try {
            Log.i(TAG, "getCurrentAddress:  latitude:"+latitude+" longitude "+longitude);
            addresses = geocoder.getFromLocation( latitude, longitude, 100);

        } catch (IOException ioException) {
            //네트워크 문제
            Toast.makeText(this, "지오코더 서비스 사용불가", Toast.LENGTH_LONG).show();
            //showDialogForLocationServiceSetting();
            Log.i(TAG, "getCurrentAddress: 성공 ");
            return "지오코더 서비스 사용불가";
        } catch (IllegalArgumentException illegalArgumentException) {
            Toast.makeText(this, "잘못된 GPS 좌표", Toast.LENGTH_LONG).show();
            Log.i(TAG, "getCurrentAddress: 실패 잘못된 GPS 좌표");
            //showDialogForLocationServiceSetting();
            return "잘못된 GPS 좌표";
        } if (addresses == null || addresses.size() == 0) {
            Toast.makeText(this, "주소 미발견", Toast.LENGTH_LONG).show();
            Log.i(TAG, "getCurrentAddress: 주소 미발견");
            //showDialogForLocationServiceSetting();
            return "주소 미발견";
        } Address address = addresses.get(0);
        Log.i(TAG, address.getAddressLine(0).toString());
        return address.getAddressLine(0).toString()+"\n";


    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // Add a marker in Sydney and move the camera
        LatLng mylocation = new LatLng(mLatitude, mLongitude);
        mMap.addMarker(new MarkerOptions().position(mylocation).title("현재 내 위치"));
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(mylocation,18)); //지도 크게 보이게 확대하는것*/
        Random random = new Random();




        if(policela.size()>0){
            for(int i=0; i<policela.size(); i++){
                MarkerOptions markerOptions = new MarkerOptions();
                LatLng policeLocation = new LatLng(policela.get(i),policelo.get(i));
                markerOptions.position(policeLocation);
                markerOptions.title(policename.get(i));
                BitmapDrawable bitmapdraw=(BitmapDrawable)getResources().getDrawable(R.drawable.police);
                Bitmap b=bitmapdraw.getBitmap();
                Bitmap smallMarker = Bitmap.createScaledBitmap(b, 100, 100, false);
                markerOptions.icon(BitmapDescriptorFactory.fromBitmap(smallMarker));
                mMap.addMarker(markerOptions);
            }

            if(bellla.size()>0) {
                for (int i = 0; i < bellla.size(); i++) {
                    MarkerOptions markerOptions = new MarkerOptions();
                    LatLng policeLocation = new LatLng(bellla.get(i), belllo.get(i));
                    markerOptions.position(policeLocation);
                    markerOptions.title(bellname.get(i));
                    BitmapDrawable bitmapdraw = (BitmapDrawable) getResources().getDrawable(R.drawable.bell);
                    Bitmap b = bitmapdraw.getBitmap();
                    Bitmap smallMarker = Bitmap.createScaledBitmap(b, 100, 100, false);
                    markerOptions.icon(BitmapDescriptorFactory.fromBitmap(smallMarker));
                    mMap.addMarker(markerOptions);
                }
            }


        }

        //랜덤하게 취약지점 설정
        for(int i=1; i<40;i++){
            double d1=random.nextInt(10)*0.001+mLatitude;
            double d2=random.nextInt(10)*0.001+mLongitude;
            la.add(d1);
            lo.add(d2);
            onAddMarker(d1,d2);
        }



    }





    public void fadeMarker(final Marker marker) {
        //Make the marker fade
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            float f;
            int i = 2;
            int timer;
            @Override
            public void run() {
                if(i%2 == 0)
                {
                    f = 1f;
                }
                else
                    f = 0f;
                marker.setAlpha(f);
                i++;
                timer = timer + 300;

                handler.postDelayed(this, 300);

            }
        });

    }




    public void onAddMarker(double Latitude,double Longitude){
        //마커 위치 지정
        LatLng position = new LatLng(Latitude , Longitude);

        //나의위치 마커
        MarkerOptions mymarker = new MarkerOptions()
                .position(position);   //마커위치

        // 반경 1KM원
        CircleOptions circle1KM = new CircleOptions().center(position) //원점
                .radius(50)      //반지름 단위 : m
                .strokeWidth(0f)  //선너비 0f : 선없음
                .fillColor(Color.parseColor("#59A52A2A")); //배경색

        //마커추가
        //this.mMap.addMarker(mymarker);

        //원추가
        this.mMap.addCircle(circle1KM);
    }

    public void clicked(View v){
        Intent intent;
        double distance=0;
        double smallDistance=1000000;
        int minDisObject=0;

        switch(v.getId()){
            case R.id.btnSecurityBell:
                Log.i(TAG, "clicked: btnSecurityBell");
                for(int i=0; i<belllo.size();i++){
                    distance = dc.distance(mLatitude,mLongitude,bellla.get(i),belllo.get(i),"meter");
                    if(smallDistance>distance){
                        smallDistance=distance;
                        minDisObject=i;
                    }

                }
                MarkerOptions markerOptions2 = new MarkerOptions();
                LatLng policeLocation = new LatLng(bellla.get(minDisObject),belllo.get(minDisObject));
                markerOptions2.position(policeLocation);
                markerOptions2.title(bellname.get(minDisObject));
                BitmapDrawable bitmapdraw=(BitmapDrawable)getResources().getDrawable(R.drawable.bell2);
                Bitmap b=bitmapdraw.getBitmap();
                Bitmap smallMarker = Bitmap.createScaledBitmap(b, 100, 100, false);
                markerOptions2.icon(BitmapDescriptorFactory.fromBitmap(smallMarker));
                mMap.addMarker(markerOptions2);
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(policeLocation,18)); //지도 크게 보이게 확대하는것*/

                break;
            case R.id.btnPolice:
                Log.i(TAG, "clicked: btnPolice");
                if(policelo.size()>0){

                    for(int i=0; i<policelo.size();i++){
                       distance = dc.distance(mLatitude,mLongitude,policela.get(i),policelo.get(i),"meter");
                       if(smallDistance>distance){
                           smallDistance=distance;
                           minDisObject=i;
                       }

                    }
                    MarkerOptions markerOptions = new MarkerOptions();
                    LatLng policeLocation2 = new LatLng(policela.get(minDisObject),policelo.get(minDisObject));
                    markerOptions.position(policeLocation2);
                    markerOptions.title(policename.get(minDisObject));
                    BitmapDrawable bitmapdraw2=(BitmapDrawable)getResources().getDrawable(R.drawable.lapol);
                    Bitmap b2=bitmapdraw2.getBitmap();
                    Bitmap smallMarker2 = Bitmap.createScaledBitmap(b2, 100, 100, false);
                    markerOptions.icon(BitmapDescriptorFactory.fromBitmap(smallMarker2));
                    mMap.addMarker(markerOptions);
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(policeLocation2,18)); //지도 크게 보이게 확대하는것*/

                }

                break;
            case R.id.btnEmergencyCall:
                //112에 먼저 문자를 보냄
                String phoneNumber = "112";
                sendMassage(phoneNumber);
                //저장된 전화번호 리스트에 차례대로 다 보냄
                for(int i=0; i<PHlist.size(); i++){
                    Log.i(TAG, ""+PHlist.get(i));
                    sendMassage(PHlist.get(i));
                }
                break;
            case R.id.newLinkBtn:
                Intent intent2 = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
                startActivity(intent2);
                break;
            case R.id.btnBiff:
                intent = new Intent(this, ButtonPage.class);
                startActivity(intent);
                break;
            case R.id.btnSetting:
                intent = new Intent(this, SettingActivity.class);
                startActivity(intent);
                break;


        }
    }


    public void infomations(Thread thread) {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            int i = 0;

            @Override
            public void run() {
                //뉴스 어레이
                ArrayList<String> newsArray=((ApiNaverNews) thread).arrayRes();
                String text="";


                if (newsArray.size()>i) {

                    text = newsArray.get(i);

                    //링크저장
                    link = newsArray.get(i+1);
                    newstxt.setText(text);


                    //제목 클릭시 링크 처리
                    newstxt.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
                            startActivity(intent);
                        }
                    });



                    i+=2;
                    if(newsArray.size()==i){
                        i=0;
                    }
                    handler.postDelayed(this,5000);
                }
            }
        },5000);
    }
    public void readSql(String table){
        sql ="select * from "+table;
        Cursor cursor = database.rawQuery(sql,null);
        if(table.equals("savingphone")){
            for (int i=0 ; i<cursor.getCount();i++){
                cursor.moveToNext();
                String mobile = cursor.getString(2);
                PHlist.add(mobile);
            }
        }else if(table.equals("PoliceLocation")){

            for (int i=0 ; i<cursor.getCount();i++){
                cursor.moveToNext();
                String name = cursor.getString(2);
                double la=cursor.getDouble(3);
                double lo=cursor.getDouble(4);
                policename.add(name);
                policela.add(la);
                policelo.add(lo);
            }

        }else if(table.equals("BellLocation")){
            for (int i=0 ; i<cursor.getCount();i++){
                cursor.moveToNext();
                String bellname1 = cursor.getString(2);
                double bellla1=cursor.getDouble(3);
                double belllo1=cursor.getDouble(4);
                Log.i(TAG, "bellname1: "+bellname1);
                bellname.add(bellname1);
                bellla.add(bellla1);
                belllo.add(belllo1);
            }


            Log.i(TAG, "policename: "+policename+" bellname : "+bellname);

        }


        cursor.close();
    }
    public void sendMassage(String phoneNumber){
        String message = "안심 귀가 어플에서 발송한 메세지입니다. 현재 위험한 상태입니다." +
                "\n 현재 위치 : "+Address+"\n 현재 좌표 : "+mLatitude+","+mLongitude;
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(getApplicationContext(), "전송 완료!", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "전송 오류!", Toast.LENGTH_LONG).show();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();//오류 원인이 찍힌다.
            e.printStackTrace();
        }
    }
}