package com.example.mymapapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static String DBName ="person.db";
    public static int VERSION =1;
    final String TAG ="DataHelper";


    public DatabaseHelper(@Nullable Context context) {
        super(context, DBName, null, VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        println("onCreate() 호출");
        String sql ="create table if not exists emp(" +
                "_id integer primary key autoincrement," +
                "name text," +
                "mobile text)";
        db.execSQL(sql);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        //super.onOpen(db);
        println("onOpen() 호출");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        println("onUpgrade() 호출됨 : "+oldVersion+"=>"+newVersion);
        if (newVersion>1){
            db.execSQL("drop table if exists emp");

        }
    }
    private void println(String str){
        Log.i(TAG,str);
    };
}
