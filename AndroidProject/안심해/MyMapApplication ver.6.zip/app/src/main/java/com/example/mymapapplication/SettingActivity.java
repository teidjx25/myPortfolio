package com.example.mymapapplication;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;


public class SettingActivity extends AppCompatActivity {

    DatabaseHelper dataHelper;
    SQLiteDatabase database;
    String tableName,sql;
    final String TAG ="test";
    private static final float FONT_SIZE = 20;
    LinearLayout container;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        setTitle("비상번호 관리");
        container =findViewById(R.id.container);
        //db정보 없으면 생성을 시작
        if (database==null){
            dataHelper=new DatabaseHelper(this);
            database=dataHelper.getWritableDatabase();
            tableName ="savingphone";
            sql ="create table if not exists "+tableName+"(" +
                    "_id integer primary key autoincrement," +
                    "name text," +
                    "mobile text)";
            database.execSQL(sql);
        }


        //select 메소드 호출
        readSql();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i(TAG, "onRestart: ");
        //다시 시작하면 select 메소드 호출
        //이미 생성된 뷰가 있기 때문에 전부 지우고 다시 생성
        container.removeAllViews();
        readSql();


    }
    //sqlLite Select 메서드
    public void readSql(){
        sql ="select * from "+tableName;
        Cursor cursor = database.rawQuery(sql,null);
        for (int i=0 ; i<cursor.getCount();i++){
            cursor.moveToNext();
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String mobile = cursor.getString(2);
            textview(id+":"+" 이름 : "+name +"    번호 : "+mobile,name);
        }
        cursor.close();
    }
    //텍스트뷰 생성 하는 메서드
    public void textview(String a,String name){
        //TextView 생성
        TextView view1 = new TextView(this);
        view1.setText(a);
        view1.setTextSize(FONT_SIZE);
        view1.setTextColor(Color.BLACK);

        //layout_width, layout_height, gravity 설정
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.LEFT;

        view1.setLayoutParams(lp);
        view1.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                database.delete(tableName,"name=?",new String[]{name});
                Intent intent = getIntent();
                finish();
                startActivity(intent);
                return true;
            }
        });
        //부모 뷰에 추가
        container.addView(view1);
    }
    //버튼 클릭 이벤트 관리
    public void SqlClicked(View v){
        Intent intent =new Intent(this, InsertActivity.class);
        switch (v.getId()){
            case R.id.btnInsert:
                intent.putExtra("tableName",tableName);
                startActivity(intent);
                break;
            case R.id.btnFinish:
                finish();
                break;

        }
    }

    private void println(String str){
        Log.i(TAG, str);;
    }

}