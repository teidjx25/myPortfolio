package org.pky.service;

import java.util.List;

import org.pky.domain.police;
import org.pky.mapper.BoardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BoardServiceImpl implements BoardService {
	@Autowired
	BoardMapper boardMapper;
	
	@Override
	public List<police> PoliceList(String Location) throws Exception {
		// TODO Auto-generated method stub
		System.out.println(boardMapper.PoliceList(Location));
		return boardMapper.PoliceList(Location);
	}

	@Override
	public List<police> BellList(String Location) throws Exception {
		// TODO Auto-generated method stub
		return boardMapper.BellList(Location);
	}

}
