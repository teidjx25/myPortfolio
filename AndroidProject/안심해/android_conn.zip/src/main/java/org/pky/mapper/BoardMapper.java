package org.pky.mapper;

import java.util.List;

import org.pky.domain.police;


public interface BoardMapper {

	public List<police>PoliceList(String Location) throws Exception;
	public List<police>BellList(String Location) throws Exception;
	//public List<police>list() throws Exception;
	//public List<police>list() throws Exception;

}
