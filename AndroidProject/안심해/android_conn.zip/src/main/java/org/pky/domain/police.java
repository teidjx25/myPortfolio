package org.pky.domain;

import java.io.Serializable;

import lombok.Data;


public class police {
    private String gucode;
    private String name;
    private double la;
    private double lo;
    
	public String getGucode() {
		return gucode;
	}
	public void setGucode(String gucode) {
		this.gucode = gucode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getLa() {
		return la;
	}
	public void setLa(double la) {
		this.la = la;
	}
	public double getLo() {
		return lo;
	}
	public void setLo(double lo) {
		this.lo = lo;
	}
	@Override
	public String toString() {
		return "police [gucode=" + gucode + ", name=" + name + ", la=" + la + ", lo=" + lo + "]";
	}
	
	
}