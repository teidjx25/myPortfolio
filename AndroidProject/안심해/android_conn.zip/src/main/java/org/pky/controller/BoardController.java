package org.pky.controller;

import java.util.List;

import org.pky.domain.police;
import org.pky.mapper.BoardMapper;
import org.pky.service.BoardServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.extern.java.Log;

@Log
@Controller
@RequestMapping("/board")
public class BoardController {
	
	@Autowired
	BoardServiceImpl boardservice;
	

	@ResponseBody
	@GetMapping("/policeLocation")
	public List<police> pollistBody(Model model,String Location) throws Exception{
		List<police> list = boardservice.PoliceList(Location);
		model.addAttribute("list",list);
		System.out.println(list);
		return list;
	}
	@ResponseBody
	@GetMapping("/bellLocation")
	public List<police> belllistBody(Model model,String Location) throws Exception{
		List<police> list = boardservice.BellList(Location);
		model.addAttribute("list",list);
		return list;
	}
	
	
}
