package org.pky.service;

import java.util.List;

import org.pky.domain.police;

public interface BoardService {
	public List<police>PoliceList(String Location) throws Exception;
	public List<police>BellList(String Location) throws Exception;
}
