package org.pky.domain;

import lombok.Data;

@Data
public class UserSelectVO {
    private int areaCode;
    private String areaCodeName;

    private int sigunguCode;
    private String sigunguCodeName;

    private int personNum;
    private int StartDate;
    private int endDate;
}
