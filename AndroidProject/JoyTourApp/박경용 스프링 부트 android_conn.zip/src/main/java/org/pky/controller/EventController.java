package org.pky.controller;

import java.util.List;

import org.pky.domain.Board;
import org.pky.domain.EventVO;
import org.pky.domain.UserRouteVO;
import org.pky.domain.UserSelectVO;
import org.pky.domain.routeName;
import org.pky.service.BoardServiceImpl;
import org.pky.service.EventServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/Event")
public class EventController {
	
	@Autowired
	private EventServiceImpl eventservice;
	
	@ResponseBody
	@PostMapping("/androidRegister")
	public String Androidregister(String addr1, String areacode, String sigungucode , String contentid ,String contenttypeid ,String eventstartdate ,String eventenddate ,String firstimage ,String mapx ,String mapy ,String readcount ,String tel ,String title ,Model model) throws Exception {
		EventVO eventvo = new EventVO();
		eventvo.setTitle(title);
		eventvo.setAddr1(addr1);
		eventvo.setAreacode(Integer.parseInt(areacode));
		eventvo.setSigungucode(Integer.parseInt(sigungucode));
		eventvo.setContentid(Integer.parseInt(contentid));
		eventvo.setContenttypeid(Integer.parseInt(contenttypeid));
		eventvo.setEventenddate(Integer.parseInt(eventenddate));
		eventvo.setEventstartdate(Integer.parseInt(eventstartdate));
		eventvo.setFirstimage(firstimage);
		eventvo.setMapx(Double.parseDouble(mapx));
		eventvo.setMapy(Double.parseDouble(mapy));
		eventvo.setReadcount(Integer.parseInt(readcount));
		eventvo.setTel(tel);
		eventservice.register(eventvo);
		return "저장 완료";
	}
	
	@ResponseBody
	@PostMapping("/routeSave")
	public String routeSave(String routeName,Model model) throws Exception {
		
		
		int num[]= {12,32};
		int num2= 14;
		List<EventVO> list = eventservice.listing(15);
		for(int i=0;i<num.length;i++) {
			list.addAll(eventservice.listing(num[i]));
			if(num[i]==12) {
				list.addAll(0, eventservice.listing(num2));
			}
		}
		

		
		List<UserSelectVO> usvo = eventservice.usList();
		UserRouteVO eventvo = new UserRouteVO();
		
		String dateInf= usvo.get(0).getStartDate() + " ~ " + usvo.get(0).getEndDate();
		for(int i=0;i<list.size();i++) {
			

			eventvo.setRouteName(routeName);
			eventvo.setRouteDate(dateInf);
			eventvo.setPersonNum(usvo.get(0).getPersonNum());
			eventvo.setAreaName(usvo.get(0).getAreaCodeName());
			eventvo.setSigunguName(usvo.get(0).getSigunguCodeName());
			eventvo.setAreacode(usvo.get(0).getAreaCode());
			eventvo.setSigungucode(usvo.get(0).getSigunguCode());
			
			eventvo.setChoiceDate(list.get(i).getChoiceDate());
			eventvo.setTitle(list.get(i).getTitle());
			eventvo.setAddr1(list.get(i).getAddr1());

			eventvo.setContentid(list.get(i).getContentid());
			eventvo.setContenttypeid(list.get(i).getContenttypeid());
			eventvo.setEventenddate(list.get(i).getEventenddate());
			eventvo.setEventstartdate(list.get(i).getEventstartdate());
			eventvo.setFirstimage(list.get(i).getFirstimage());
			eventvo.setMapx(list.get(i).getMapx());
			eventvo.setMapy(list.get(i).getMapy());
			eventvo.setReadcount(list.get(i).getReadcount());
			eventvo.setTel(list.get(i).getTel());
			eventservice.registerRoute(eventvo);
		}


	    
		return "저장 완료";
	}
	
	@ResponseBody
	@GetMapping("/listBody")
	public List<EventVO> listBody(Model model,int num,int num2) throws Exception{
		
		List<EventVO> list = eventservice.listing(num);
		if(num2!=0) {
			list.addAll(0, eventservice.listing(num2));
		}
		
		model.addAttribute("list",list);
		return list;
	}
	@ResponseBody
	@GetMapping("/delete")
	public String listBody(int num) throws Exception{
		
		eventservice.remove(num);
		return "삭제되었습니다.";
	}
	@ResponseBody
	@GetMapping("/routeUpdate")
	public String routeUpdate(int choiceDate, int routeid) throws Exception {
		
		EventVO us =eventservice.read(routeid);
		us.setChoiceDate(choiceDate);
		eventservice.modify(us);
		
		return "저장 완료";
	}
	@ResponseBody
	@PostMapping("/userSelectRegister")
	public String userSelectRegister(String areaCode, String areaCodeName, String sigunguCode , String sigunguCodeName ,String StartDate ,String endDate ,String personNum) throws Exception {
		if(eventservice.usCount()>0) {
			eventservice.usRemove(0);
		}
		UserSelectVO us =new UserSelectVO();
		us.setAreaCode(Integer.parseInt(areaCode));
		us.setAreaCodeName(areaCodeName);
		us.setSigunguCode(Integer.parseInt(sigunguCode));
		us.setSigunguCodeName(sigunguCodeName);
		us.setStartDate(Integer.parseInt(StartDate));
		us.setEndDate(Integer.parseInt(endDate));
		us.setPersonNum(Integer.parseInt(personNum));
		eventservice.usRegister(us);
		return "저장 완료";
	}
	

	
	@ResponseBody
	@GetMapping("/datelist")
	public List<UserSelectVO> datelist(Model model) throws Exception{
		
		List<UserSelectVO> vo = eventservice.usList();
		model.addAttribute("list",vo);
		return vo;
	}
	
	//루트 자세한 정보
	@ResponseBody
	@GetMapping("/selectRouteInfo")
	public List<UserRouteVO> selectRouteInfo(Model model,String id) throws Exception{
		System.out.println(id);
		List<UserRouteVO> list = eventservice.selectRouteInfo(id);
		System.out.println(list);
		model.addAttribute("list",list);
		return list;
	}
	//루트 이름들만 나열
	@ResponseBody
	@GetMapping("/routeList")
	public List<routeName> routeList(Model model) throws Exception{
		
		List<routeName> list = eventservice.routeList();
		model.addAttribute("list",list);
		return list;
	}
	//루트 삭제
	@ResponseBody
	@GetMapping("/deleteRouteInfo")
	public String deleteRouteInfo(String id) throws Exception{
		
		eventservice.deleteRouteInfo(id);
		return "삭제되었습니다.";
	}
}
