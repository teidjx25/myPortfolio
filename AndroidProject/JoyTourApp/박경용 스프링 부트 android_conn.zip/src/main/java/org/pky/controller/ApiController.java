package org.pky.controller;


import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.pky.domain.Code;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

@Controller
@RequestMapping("/Api")
public class ApiController {
	
	private final String serviceKey ="7W%2FcZNCxnT2mBSdPEJtSaa3zDS6Vg7XuBgyW1MTPIoXvi3UgTzb%2Fdo%2F25%2FyXIJKlmADRJ4RcI%2FQst%2FSAHzT89g%3D%3D";
	private String URL = "";
	String Option = "?serviceKey="+serviceKey+"&MobileOS=ETC"+"&MobileApp=AppTest";
	public ArrayList<Code> areaCodeList = new ArrayList<Code>();
	
	
	//api의 area코드 출력
	@GetMapping("/test2")
	@ResponseBody
	public ArrayList<Code> test2() throws Exception {
		URL = "http://api.visitkorea.or.kr/openapi/service/rest/KorService/areaCode";
		String name;
		int code;
		int rnum;

		try {
		    String strUrl =URL+Option;
		
		    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		    DocumentBuilder builder = factory.newDocumentBuilder();
		    Document document = builder.parse(strUrl);
		    
		    NodeList nodeName = document.getElementsByTagName("name"); 
		    NodeList nodeCode = document.getElementsByTagName("code");
		    NodeList nodeRnum = document.getElementsByTagName("rnum");
		    
		    for(int i=0; nodeName.item(i)!=null;i++ ) {
		    
		    name =nodeName.item(i).getFirstChild().getNodeValue().toString();
		    code =Integer.parseInt(nodeCode.item(i).getFirstChild().getNodeValue().toString());
		    rnum = Integer.parseInt(nodeRnum.item(i).getFirstChild().getNodeValue().toString());
		    Code codeObject = new Code();
		    codeObject.setCode(code);
		    codeObject.setName(name);
		    codeObject.setRnum(rnum);
		    
		    areaCodeList.add(codeObject);
		    
		    }
		    System.out.println(areaCodeList); 
		    
			} catch(Exception e) {
			    throw e;
				
			}
		return areaCodeList;
	}
			
			
	
	
	
	
	
	
	
	
	
	
	
	
}
