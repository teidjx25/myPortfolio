package org.pky.domain;

import lombok.Data;

@Data
public class routeName {
	private String routeName;
	private int count;
}
