package org.pky.service;

import java.util.List;

import org.pky.domain.Board;
import org.pky.domain.EventVO;
import org.pky.domain.UserRouteVO;
import org.pky.domain.UserSelectVO;
import org.pky.domain.routeName;

public interface EventService {
	public void register(EventVO event) throws Exception;
	
	public void registerRoute(UserRouteVO event) throws Exception;
	
	public EventVO read(Integer bno) throws Exception;
	public void modify(EventVO event) throws Exception;
	public void remove(Integer bno) throws Exception;
	public List<EventVO> list() throws Exception;
	public List<EventVO> listing(int num) throws Exception;
	
	public UserSelectVO usRead(Integer bno) throws Exception;
	public void usRegister(UserSelectVO us) throws Exception;
	public void usModify(UserSelectVO us) throws Exception;
	public void usRemove(Integer bno) throws Exception;
	public List<UserSelectVO> usList() throws Exception;
	public int usCount() throws Exception;
	
	public void RouteDelete(Integer bno) throws Exception;
	public int RouteCnt() throws Exception;
	public UserRouteVO RouteRead (String routeid) throws Exception;
	
	
	public void deleteRouteInfo (String routeName) throws Exception;
	public List<UserRouteVO> selectRouteInfo (String routeName) throws Exception;
	public List<routeName> routeList () throws Exception;

}
