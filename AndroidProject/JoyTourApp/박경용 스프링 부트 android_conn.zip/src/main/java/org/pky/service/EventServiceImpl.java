package org.pky.service;

import java.util.List;

import org.pky.domain.Board;
import org.pky.domain.EventVO;
import org.pky.domain.UserRouteVO;
import org.pky.domain.UserSelectVO;
import org.pky.domain.routeName;
import org.pky.mapper.EventMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class EventServiceImpl implements EventService {
	@Autowired
	EventMapper eventMapper;
	
	@Override
	public void register(EventVO event) throws Exception {
		// TODO Auto-generated method stub
	eventMapper.create(event);
	}

	@Override
	public EventVO read(Integer routeid) throws Exception {
		// TODO Auto-generated method stub
		return eventMapper.read(routeid);
	}

	@Override
	public void modify(EventVO event) throws Exception {
		// TODO Auto-generated method stub
		eventMapper.update(event);
	}

	@Override
	public void remove(Integer bno) throws Exception {
		// TODO Auto-generated method stub
		eventMapper.delete(bno);

	}

	@Override
	public List<EventVO> list() throws Exception {
		// TODO Auto-generated method stub
		return eventMapper.list();
	}

	@Override
	public List<EventVO> listing(int num) throws Exception {
		// TODO Auto-generated method stub
		return eventMapper.listing(num);
	}

	
	
	
	

	@Override
	public UserSelectVO usRead(Integer bno) throws Exception {
		// TODO Auto-generated method stub
		return eventMapper.usRead(bno);
	}

	@Override
	public void usRegister(UserSelectVO us) throws Exception {
		eventMapper.usRegister(us);
		
	}

	@Override
	public void usModify(UserSelectVO us) throws Exception {
		// TODO Auto-generated method stub
	
	}

	@Override
	public void usRemove(Integer bno) throws Exception {
		// TODO Auto-generated method stub
		eventMapper.usRemove(bno);
	}

	@Override
	public List<UserSelectVO> usList() throws Exception {
		// TODO Auto-generated method stub
		return eventMapper.usList();
	}

	@Override
	public int usCount() throws Exception {
		// TODO Auto-generated method stub
		return eventMapper.usCount();
	}

	@Override
	public void registerRoute(UserRouteVO event) throws Exception {
		// TODO Auto-generated method stub
		eventMapper.registerRoute(event);
	}



	@Override
	public int RouteCnt() throws Exception {
		// TODO Auto-generated method stub
		return eventMapper.RouteCnt();
	}

	@Override
	public UserRouteVO RouteRead(String routeid) throws Exception {
		// TODO Auto-generated method stub
		return eventMapper.RouteRead(routeid);
	}

	@Override
	public void RouteDelete(Integer bno) throws Exception {
		// TODO Auto-generated method stub
		eventMapper.RouteDelete(bno);
	}

	@Override
	public void deleteRouteInfo(String routeName) throws Exception {
		// TODO Auto-generated method stub
		eventMapper.deleteRouteInfo(routeName);
	}

	@Override
	public List<UserRouteVO> selectRouteInfo(String routeName) throws Exception {
		// TODO Auto-generated method stub
		return eventMapper.selectRouteInfo(routeName);
	}

	@Override
	public List<routeName> routeList() throws Exception {
		// TODO Auto-generated method stub
		return eventMapper.routeList();
	}


	


	



}
