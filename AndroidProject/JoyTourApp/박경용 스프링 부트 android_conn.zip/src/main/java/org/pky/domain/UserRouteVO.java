package org.pky.domain;

import lombok.Data;

@Data
public class UserRouteVO {
	
    private String routeName;
    private String routeDate;
    private int personNum;
    private int choiceDate;
    private String areaName;
    private String sigunguName;

    private int routeid;
    private String addr1;
    private int areacode;
    private int sigungucode;
    private int contentid;
    private int contenttypeid;
    private int eventstartdate;
    private int eventenddate;
    private String firstimage;
    private double mapx;
    private double mapy;
    private int readcount;

    private String tel;
    private String title;
}
