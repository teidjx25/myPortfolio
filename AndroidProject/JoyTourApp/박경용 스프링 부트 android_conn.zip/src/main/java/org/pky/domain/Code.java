package org.pky.domain;

import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;


@Data

public class Code {
	private int code;
	private String name;
	private int rnum;
}
