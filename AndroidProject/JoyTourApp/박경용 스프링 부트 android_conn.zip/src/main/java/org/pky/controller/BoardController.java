package org.pky.controller;

import java.util.List;

import org.pky.domain.Board;
import org.pky.service.BoardService;
import org.pky.service.BoardServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.extern.java.Log;

@Log
@Controller
@RequestMapping("/board")
public class BoardController {
	@Autowired
	private BoardServiceImpl boardservice;
	
	@GetMapping("/register")
	public void registerForm() throws Exception{
		
	}
	@ResponseBody
	@PostMapping("/androidRegister")
	public String Androidregister(String title, String content, String writer ,Model model) throws Exception {
		Board board = new Board();
		board.setTitle(title);
		board.setContent(content);
		board.setWriter(writer);
		boardservice.register(board);
		return "저장 완료";
	}
	@PostMapping("/register")
	public String register(Board board,Model model) throws Exception {
		boardservice.register(board);
		return "redirect:/board/list";
	}
	@GetMapping("/list")
	public void list(Model model) throws Exception{
		List<Board> list = boardservice.list();
		model.addAttribute("list",list);
	}
	@ResponseBody
	@GetMapping("/listBody")
	public List<Board> listBody(Model model) throws Exception{
		List<Board> list = boardservice.list();
		model.addAttribute("list",list);
		return list;
	}
	
	@GetMapping("/read")
	public void read(@RequestParam("bno") Integer bno, Model model) throws Exception{
		Board board = boardservice.read(bno);
		model.addAttribute("board",board);
		
	}
	
	@PostMapping("/modify")
	public String modify(Board board ) throws Exception {
		boardservice.modify(board);
		return "redirect:/board/list";
	}
	
	@GetMapping("/remove")
	public String remove(@RequestParam("bno") Integer bno ) throws Exception {
		boardservice.remove(bno);
		return "redirect:/board/list";
	}

	
}
