package org.pky.service;

import java.util.List;

import org.pky.domain.Board;
import org.pky.mapper.BoardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jdk.internal.org.jline.utils.Log;


@Service
public class BoardServiceImpl implements BoardService{
	
	@Autowired
	BoardMapper boardMapper;
	
	@Override
	public void register(Board board) throws Exception {
		// TODO Auto-generated method stub
		//Log.info("board"+board);
		boardMapper.create(board);
	}

	@Override
	public Board read(Integer bno) throws Exception {
		// TODO Auto-generated method stub
		
		return boardMapper.read(bno);
	}

	@Override
	public void modify(Board board) throws Exception {
		boardMapper.update(board);
		
	}

	@Override
	public void remove(Integer bno) throws Exception {
		boardMapper.delete(bno);
		
	}

	@Override
	public List<Board> list() throws Exception {
		// TODO Auto-generated method stub
		return boardMapper.list();
	}

}
