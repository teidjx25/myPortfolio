package org.pky;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(basePackages = "org.pky.mapper")
public class AndroidConnApplication {

	public static void main(String[] args) {
		SpringApplication.run(AndroidConnApplication.class, args);
	}

}
