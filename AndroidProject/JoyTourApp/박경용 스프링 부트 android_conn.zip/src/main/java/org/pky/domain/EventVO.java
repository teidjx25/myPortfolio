package org.pky.domain;

import lombok.Data;

@Data
public class EventVO {
	private int routeid;
	private String addr1;

    private int areacode;
    private int sigungucode;

    private int contentid;
    private int contenttypeid;

    private int eventstartdate;
    private int eventenddate;

    private String firstimage;
    private double mapx;
    private double mapy;
    private int readcount;

    private String tel;
    private String title;
    private int choiceDate;

}
