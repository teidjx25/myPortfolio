package com.example.myapplication;

import java.io.Serializable;

public class EventVO implements Serializable {


    private int routeid;
    private String addr1;

    private int areacode;
    private int sigungucode;

    private int contentid;
    private int contenttypeid;

    private int eventstartdate;
    private int eventenddate;

    private String firstimage;
    private double mapx;
    private double mapy;
    private int readcount;

    private String tel;
    private String title;
    private int Selection;
    private int choiceDate;

    public int getChoiceDate() {
        return choiceDate;
    }

    public void setChoiceDate(int choiceDate) {
        this.choiceDate = choiceDate;
    }

    public int getRouteid() {
        return routeid;
    }

    public void setRouteid(int routeid) {
        this.routeid = routeid;
    }
    public String getRanking() {
        return ranking;
    }

    public void setRanking(String ranking) {
        this.ranking = ranking;
    }

    private String ranking;

    public int getSelection() {
        return Selection;
    }

    public void setSelection(int selection) {
        Selection = selection;
    }

    public String getAddr1() {
        return addr1;
    }

    public void setAddr1(String addr1) {
        this.addr1 = addr1;
    }

    public int getAreacode() {
        return areacode;
    }

    public void setAreacode(int areacode) {
        this.areacode = areacode;
    }

    public int getSigungucode() {
        return sigungucode;
    }

    public void setSigungucode(int sigungucode) {
        this.sigungucode = sigungucode;
    }

    public int getContentid() {
        return contentid;
    }

    public void setContentid(int contentid) {
        this.contentid = contentid;
    }

    public int getContenttypeid() {
        return contenttypeid;
    }

    public void setContenttypeid(int contenttypeid) {
        this.contenttypeid = contenttypeid;
    }

    public int getEventstartdate() {
        return eventstartdate;
    }

    public void setEventstartdate(int eventstartdate) {
        this.eventstartdate = eventstartdate;
    }

    public int getEventenddate() {
        return eventenddate;
    }

    public void setEventenddate(int eventenddate) {
        this.eventenddate = eventenddate;
    }

    public String getFirstimage() {
        return firstimage;
    }

    public void setFirstimage(String firstimage) {
        this.firstimage = firstimage;
    }

    public double getMapx() {
        return mapx;
    }

    public void setMapx(double mapx) {
        this.mapx = mapx;
    }

    public double getMapy() {
        return mapy;
    }

    public void setMapy(double mapy) {
        this.mapy = mapy;
    }

    public int getReadcount() {
        return readcount;
    }

    public void setReadcount(int readcount) {
        this.readcount = readcount;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return "EventVO{" +
                "routeid=" + routeid +
                ", addr1='" + addr1 + '\'' +
                ", areacode=" + areacode +
                ", sigungucode=" + sigungucode +
                ", contentid=" + contentid +
                ", contenttypeid=" + contenttypeid +
                ", eventstartdate=" + eventstartdate +
                ", eventenddate=" + eventenddate +
                ", firstimage='" + firstimage + '\'' +
                ", mapx=" + mapx +
                ", mapy=" + mapy +
                ", readcount=" + readcount +
                ", tel='" + tel + '\'' +
                ", title='" + title + '\'' +
                ", Selection=" + Selection +
                ", choiceDate=" + choiceDate +
                ", ranking='" + ranking + '\'' +
                '}';
    }
}
