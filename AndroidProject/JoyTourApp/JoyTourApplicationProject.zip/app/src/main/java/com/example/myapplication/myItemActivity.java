package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.json.JSONException;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class myItemActivity extends AppCompatActivity {
    boolean state =false;
    ListView myListTour;
    EditText etRouteName;
    UserSelectVO userSelectVO12 = new UserSelectVO();
    TextView tvSettingPN,tvSettingDate,tvSettingLoc,textView21;
    Button btnSetting,btnTitleSetting;
    String routeName="";
    LinearLayout layoutRouteName;

    RouteVO routeVO = new RouteVO();

    static RequestQueue requestQueue;

    myItemAdepter adapterEvent,adepterLoc,adepterHotel;
    ArrayList<EventVO> EventVoAList =new ArrayList<EventVO>();
    ArrayList<EventVO> LocVoAList =new ArrayList<EventVO>();
    ArrayList<EventVO> HotelVoAList =new ArrayList<EventVO>();

    ArrayList<EventVO> RouteVoAList =new ArrayList<EventVO>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_item);
        layoutRouteName =findViewById(R.id.layoutRouteName);
        btnSetting =findViewById(R.id.btnSetting);
        tvSettingDate =findViewById(R.id.tvSettingDate);
        tvSettingPN =findViewById(R.id.tvSettingPN);
        tvSettingLoc =findViewById(R.id.tvSettingLoc);
        textView21 =findViewById(R.id.textView21);
        btnTitleSetting=findViewById(R.id.btnTitleSetting);
        userSelectVO12.setStartDate(0);
        if(requestQueue==null){
            requestQueue= Volley.newRequestQueue(getApplicationContext());
        }

        setTitle("저장된 경로들");
        SettingRequest();

        resmakeRequest(15,0);
        resmakeRequest(12,0);
        resmakeRequest(32,0);
        myListTour =findViewById(R.id.myListTour);
        etRouteName =findViewById(R.id.etRouteName);
//        Intent intent =getIntent();
//        eventVO =(EventVO) intent.getSerializableExtra("DetailInfo");
        btnSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 =new Intent(myItemActivity.this,DateSettingActivity.class);
                startActivity(intent1);
            }
        });
    }
    public void MyBtnSelect(View view){
        switch (view.getId()){
            case R.id.btnSaveEvent:
                myListTour.setAdapter(adapterEvent);
                break;
            case R.id.btnSaveLocation:
                myListTour.setAdapter(adepterLoc);
                break;
            case R.id.btnSaveHotel:
                myListTour.setAdapter(adepterHotel);
                break;
            case R.id.btnRouteNameSave:
                routeName =etRouteName.getText().toString();
                layoutRouteName.setVisibility(View.GONE);
                textView21.setVisibility(View.VISIBLE);
                textView21.setText("루트이름 : "+routeName);
                textView21.setTextColor(0xAAef484a);
                btnTitleSetting.setVisibility(View.VISIBLE);
                break;
            case R.id.btnTravelPlanSave:
                sendmakeRequest();
                break;
            case R.id.btnTravelCancel:
                finish();
                break;
            case R.id.btnTitleSetting:
                layoutRouteName.setVisibility(View.VISIBLE);
                textView21.setVisibility(View.GONE);
                btnTitleSetting.setVisibility(View.GONE);
                break;
            case R.id.btnTravel:
                Intent intent1 =new Intent(myItemActivity.this,MyRouteList.class);
                startActivity(intent1);
                break;
        }
    }
    public void sendmakeRequest(){
        String url="http://180.68.74.33:8090/Event/routeSave";
        StringRequest request=new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {

                        println("응답 ->" + response);
                        Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();
                        layoutRouteName.setVisibility(View.VISIBLE);
                        textView21.setVisibility(View.GONE);
                        btnTitleSetting.setVisibility(View.GONE);

                        //processResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        println("에러 ->" + error.getMessage());
                    }
                }
        ){ @Override //response를 UTF8로 변경해주는 소스코드
        protected Response<String> parseNetworkResponse(NetworkResponse response) {
            try {
                String utf8String = new String(response.data, "UTF-8");
                return Response.success(utf8String, HttpHeaderParser.parseCacheHeaders(response));
            } catch (UnsupportedEncodingException e) {
                // log error
                return Response.error(new ParseError(e));
            } catch (Exception e) {
                // log error
                return Response.error(new ParseError(e));
            }
        }
            protected Map<String,String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String,String>();
//                Log.i("tag123", "processResponse: "+routeVO.getRouteName()+routeVO.getTitle());

                params.put("routeName",routeName);



                return params;
            }
        };
        request.setShouldCache(false);
        requestQueue.add(request);
        println("요청보냄");
    }
    public void resmakeRequest(int Select,int order){

        String url="http://180.68.74.33:8090/Event/listBody?num="+Select;
        if(Select==12){
            url+="&num2=14";
        }else {
            url+="&num2=0";
        }
        StringRequest request=new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        //println("응답 ->" + response);
                        try {
                            processResponse(response,Select);
                        } catch (JSONException | ParseException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        println("에러 ->" + error.getMessage());
                    }
                }
        ){
            @Override //response를 UTF8로 변경해주는 소스코드
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                try {
                    String utf8String = new String(response.data, "UTF-8");
                    return Response.success(utf8String, HttpHeaderParser.parseCacheHeaders(response));
                } catch (UnsupportedEncodingException e) {
                    // log error
                    return Response.error(new ParseError(e));
                } catch (Exception e) {
                    // log error
                    return Response.error(new ParseError(e));
                }
            }
            protected Map<String,String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String,String>();
                return params;
            }
        };

        request.setShouldCache(false);
        requestQueue.add(request);
        println("요청보냄");
    }
    public void SettingRequest(){

        String url="http://180.68.74.33:8090/Event/datelist";

        StringRequest request=new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        println("SettingRequest 응답 ->" + response);

                        try {
                            if(response.equals("[]")) {
                                tvSettingDate.setText("");
                                tvSettingPN.setText("");
                                tvSettingLoc.setText("상세 정보가 선택되지 않았습니다.\n 선택하시길 바랍니다");
                                btnSetting.setText("선택하러가기");
                            }else {
                                dateResponse(response);
                            }

                        } catch (JSONException | ParseException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        println("에러 ->" + error.getMessage());
                    }
                }
        ){
            @Override //response를 UTF8로 변경해주는 소스코드
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                try {
                    String utf8String = new String(response.data, "UTF-8");
                    return Response.success(utf8String, HttpHeaderParser.parseCacheHeaders(response));
                } catch (UnsupportedEncodingException e) {
                    // log error
                    return Response.error(new ParseError(e));
                } catch (Exception e) {
                    // log error
                    return Response.error(new ParseError(e));
                }
            }
            protected Map<String,String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String,String>();
                return params;
            }
        };

        request.setShouldCache(false);
        requestQueue.add(request);
        println("요청보냄");
    }
    private void processResponse(String response, int Select) throws JSONException, ParseException {
        Gson gson =new Gson();
        EventVO[] eventVOS=gson.fromJson(response,EventVO[].class);
        for(int i=0; i<eventVOS.length;i++){

            if(Select==15){
                EventVoAList.add(eventVOS[i]);
                RouteVoAList.add(eventVOS[i]);
            }else if(Select==12){
                LocVoAList.add(eventVOS[i]);
                RouteVoAList.add(eventVOS[i]);
            }else {
                HotelVoAList.add(eventVOS[i]);
                RouteVoAList.add(eventVOS[i]);
            }


        }
        println("파싱한 데이터 수:"+EventVoAList.size());
        int StartDate = 0;

        if(Select==12) {
            StartDate=userSelectVO12.getStartDate()==0?0:userSelectVO12.getStartDate();
            adapterEvent = new myItemAdepter(this, R.layout.myroute, EventVoAList,StartDate);
            myListTour.setAdapter(adapterEvent);
        }else if(Select==15){
            adepterLoc = new myItemAdepter(this, R.layout.myroute, LocVoAList,StartDate);
        }else {
            adepterHotel = new myItemAdepter(this, R.layout.myroute, HotelVoAList,StartDate);
        }






    }
    private void dateResponse(String response ) throws JSONException, ParseException {


        Gson gson =new Gson();
        UserSelectVO[] userSelectVOS=gson.fromJson(response,UserSelectVO[].class);
        if(userSelectVOS==null){
            println("비었음");
        }else {
            userSelectVO12=userSelectVOS[0];
            String str="";
            str+="선택된 지역 : "+userSelectVO12.getAreaCodeName();
            if(userSelectVO12.getSigunguCode()!=9999) {
                str += "\n 선택된 상세지역 : " + userSelectVO12.getSigunguCodeName();
            }
            tvSettingLoc.setText(str);


            String StartStr =userSelectVO12.getStartDate()+"";
            String EndStr =userSelectVO12.getEndDate()+"";

            str="날짜 : "+StartStr + " ~ " +EndStr;
            tvSettingDate.setText(str);
            str="인원 : "+userSelectVO12.getPersonNum();
            tvSettingPN.setText(str);

            btnSetting.setText("수정하기");
            state=true;
        }




    }

    private void println(String str){
        Log.i("test123", "println: "+str+"\n");
    }
}