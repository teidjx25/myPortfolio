package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.json.JSONException;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class RouteDetail extends AppCompatActivity {
    TextView tvDate,tvPN,tvLoc;
    ListView TouredList;
    static RequestQueue requestQueue;
    String id;
    ArrayList<RouteVO> EventVoAList = new ArrayList<RouteVO>();
    ArrayList<RouteVO> LocVoAList = new ArrayList<RouteVO>();
    ArrayList<RouteVO> HotelVoAList = new ArrayList<RouteVO>();

    RouteDatailAdepter adapterEvent,adepterLoc,adepterHotel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_route_detail);
        tvDate =findViewById(R.id.tvDate);
        tvPN =findViewById(R.id.tvPN);
        tvLoc =findViewById(R.id.tvLoc);
        TouredList =findViewById(R.id.TouredList);
        if(requestQueue==null){
            requestQueue= Volley.newRequestQueue(getApplicationContext());
        }
        setTitle("선택된 루트");
        Intent intent = getIntent();
        id=intent.getStringExtra("id");

        Log.i("tag123", "id : "+id);

        resmakeRequest(15,id);
    }

    public void BtnSelected(View view){
        switch(view.getId()){
            case R.id.btnSaveEvented :
                TouredList.setAdapter(adapterEvent);
                break;
            case R.id.btnSaveLocationed :
                TouredList.setAdapter(adepterLoc);
                break;
            case R.id.btnSaveHoteled :
                TouredList.setAdapter(adepterHotel);
                break;
            case R.id.btnTravelCanceled :
                finish();
                break;
        }
    }
    public void resmakeRequest(int Select,String id){

        String url="http://180.68.74.33:8090/Event/selectRouteInfo?id="+id;

        StringRequest request=new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                       // println("디테일 응답 ->" + response);
                        try {
                            processResponse(response);
                        } catch (JSONException | ParseException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        println("에러 ->" + error.getMessage());
                    }
                }
        ){
            @Override //response를 UTF8로 변경해주는 소스코드
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                try {
                    String utf8String = new String(response.data, "UTF-8");
                    return Response.success(utf8String, HttpHeaderParser.parseCacheHeaders(response));
                } catch (UnsupportedEncodingException e) {
                    // log error
                    return Response.error(new ParseError(e));
                } catch (Exception e) {
                    // log error
                    return Response.error(new ParseError(e));
                }
            }
            protected Map<String,String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String,String>();
                return params;
            }
        };

        request.setShouldCache(false);
        requestQueue.add(request);
        println("요청보냄");
    }
    private void processResponse(String response) throws JSONException, ParseException {
        Gson gson =new Gson();
        RouteVO[] eventVOS=gson.fromJson(response,RouteVO[].class);
        for(int i=0; i<eventVOS.length;i++){

            if(eventVOS[i].getContenttypeid()==15){
                EventVoAList.add(eventVOS[i]);

            }else if(eventVOS[i].getContenttypeid()==12){
                LocVoAList.add(eventVOS[i]);

            }else {
                HotelVoAList.add(eventVOS[i]);

            }


        }
        println("EventVoAList 파싱한 데이터 수:"+EventVoAList.size());
        println("LocVoAList 파싱한 데이터 수:"+LocVoAList.size());
        println("HotelVoAList 파싱한 데이터 수:"+HotelVoAList.size());

        adapterEvent = new RouteDatailAdepter(this, R.layout.myroute, EventVoAList);
        adepterLoc = new RouteDatailAdepter(this, R.layout.myroute, LocVoAList);
        adepterHotel = new RouteDatailAdepter(this, R.layout.myroute, HotelVoAList);
        TouredList.setAdapter(adapterEvent);





    }
    private void println(String str){
        Log.i("test123", "println: "+str+"\n");
    }
}