package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ListviewAdapter extends BaseAdapter {
    private LayoutInflater inflater;
    private ArrayList<EventVO> data;
    private int layout;

    Context con;
    String dateInfo;
    ImageView icon;
    public ListviewAdapter(Context context, int layout, ArrayList<EventVO> data){
        con=context;
        this.inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.data=data;
        this.layout=layout;
    }

    @Override
    public int getCount(){return data.size();}
    @Override
    public String getItem(int position){
        return data.get(position).getTitle();
    }
    @Override
    public long getItemId(int position){return position;}
    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        if(convertView==null){
            convertView=inflater.inflate(layout,parent,false);
        }
        EventVO eventVO=data.get(position);
        icon=convertView.findViewById(R.id.imageView);

        TextView tvReadCount=(TextView)convertView.findViewById(R.id.tvCount);
        TextView tvRanking=(TextView)convertView.findViewById(R.id.tvRanking);
        TextView Title=(TextView)convertView.findViewById(R.id.textTop);
        TextView Location=(TextView)convertView.findViewById(R.id.textBottom);
        //이미지 설정

        String imageUrl = eventVO.getFirstimage();
        Glide.with(con).load(imageUrl).override(1200,1060).into(icon);
       // Glide.with(con).load(imageUrl).into(icon);
        if (imageUrl==null) {
            icon.setImageResource(R.drawable.no_image);
        }


        //
        //제목 설정
        Title.setText(eventVO.getTitle());
        if(eventVO.getRanking()!=null){
            tvRanking.setVisibility(View.VISIBLE);
            tvRanking.setText(eventVO.getRanking());
        }
        if(eventVO.getEventstartdate()!=0) {
            //기간 설정
            String startDate = eventVO.getEventstartdate() + "";
            String endDate = eventVO.getEventenddate() + "";
            StringBuffer orstartDate = new StringBuffer(startDate);
            orstartDate.insert(4, ".");
            orstartDate.insert(7, ".");
            StringBuffer orendDate = new StringBuffer(endDate);
            orendDate.insert(4, ".");
            orendDate.insert(7, ".");

            dateInfo = orstartDate + "~" + orendDate + "\t";

        }
        Location.setText(eventVO.getAddr1() + "\n" +dateInfo);
        if (dateInfo == null){
            Location.setText(eventVO.getAddr1());
        }
        icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(con,DetailActivity.class);
                intent.putExtra("DetailInfo",eventVO);
                con.startActivity(intent);
            }
        });





        tvReadCount.setText("👁"+eventVO.getReadcount()+"");

        return convertView;
    }


}