package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SigunguCode_Activity extends AppCompatActivity {
    RadioGroup rgp;
    Button SelectBtn;
    AreaCodeVO nowArea = new AreaCodeVO();
    static RequestQueue requestQueue;
    ArrayList<AreaCodeVO> areaCodeVOS = new ArrayList<AreaCodeVO>();
   AreaCodeVO areaCodeVO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sigungu_code_);
        rgp =findViewById(R.id.radioGroupDate);
        SelectBtn =findViewById(R.id.buttonSelect);
        setTitle("상세 지역 선택");
        Intent intent =getIntent();
        areaCodeVO = (AreaCodeVO) intent.getSerializableExtra("AreaCode");
        //1.null 처리
        if(requestQueue==null){
            requestQueue= Volley.newRequestQueue(getApplicationContext());
        }

        //2.실행문
        try {

            areaCodeVOS=AreaReq();
            //Log.i("test", "실행됨"+areaCodeVOS);
        } catch (Exception e) {
            e.printStackTrace();
        }

        rgp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                nowArea = areaCodeVOS.get(checkedId);
                Log.i("test", "nowArea: "+nowArea);

            }
        });

        SelectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("test46", "선택한 지역: "+areaCodeVO);
                if(nowArea.getName()==null){
                    nowArea.setCode(areaCodeVO.getCode());
                    nowArea.setName(areaCodeVO.getName());
                    nowArea.setSigunguCode(9999);
                    nowArea.setSigunguName("지역 ("+areaCodeVO.getName()+ ") 만 선택하기");

                }
                Log.i("test46", "현재 선택한 지역: "+nowArea);
                Intent intent = new Intent();
                intent.putExtra("AreaCode",nowArea);
                setResult(RESULT_OK,intent);
                finish();

            }
        });
    }



    public ArrayList<AreaCodeVO> AreaReq() throws Exception {
        final String serviceKey ="7W%2FcZNCxnT2mBSdPEJtSaa3zDS6Vg7XuBgyW1MTPIoXvi3UgTzb%2Fdo%2F25%2FyXIJKlmADRJ4RcI%2FQst%2FSAHzT89g%3D%3D";
        String URL ="http://api.visitkorea.or.kr/openapi/service/rest/KorService/areaCode";
        int numOfRows=50;
        int pagenum=1;

        String Option = "?serviceKey="+serviceKey+"&MobileOS=ETC"+"&MobileApp=AppTest&_type=json&numOfRows="+numOfRows+"&pageNo="+pagenum+"&areaCode="+areaCodeVO.getCode();

        String strUrl =URL+Option;

        StringRequest request=new StringRequest(Request.Method.GET, strUrl,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {

                        //Log.i("test", "응답 ->" + response);
                        try {
                            areaCodeVOS =resArea(response);
                            //Log.i("test", "응답후 areaCodeVOS ->" + areaCodeVOS);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.i("test", "에러 ->" + error.getMessage());
                    }
                }
        ){
            @Override //response를 UTF8로 변경해주는 소스코드
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                try {
                    String utf8String = new String(response.data, "UTF-8");
                    return Response.success(utf8String, HttpHeaderParser.parseCacheHeaders(response));
                } catch (UnsupportedEncodingException e) {
                    // log error
                    return Response.error(new ParseError(e));
                } catch (Exception e) {
                    // log error
                    return Response.error(new ParseError(e));
                }
            }
            protected Map<String,String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String,String>();
                return params;
            }
        };

        request.setShouldCache(false);
        requestQueue.add(request);
        Log.i("test", "요청보냄");
        return areaCodeVOS;
    }
    private ArrayList<AreaCodeVO> resArea(String response) throws JSONException {
        AreaCodeVO defaultVo = new AreaCodeVO();
        //Log.i("test", "jsonArray :"+itemStr);
        defaultVo.setName(areaCodeVO.getName());
        defaultVo.setCode(areaCodeVO.getCode());
        defaultVo.setSigunguCode(9999);
        defaultVo.setSigunguName("지역 ("+areaCodeVO.getName()+ ") 만 선택하기");
        areaCodeVOS.add(defaultVo);



        JSONObject jsonObject = new JSONObject(response);
        String items = jsonObject.getString("response");
        JSONObject resJsonArray = new JSONObject(items);
        String body = resJsonArray.getString("body");
        JSONObject ItemsArray = new JSONObject(body);
        String itemsStr = ItemsArray.getString("items");
        JSONObject ItemArray = new JSONObject(itemsStr);
        String itemStr = ItemArray.getString("item");
        JSONArray jsonArray =new JSONArray(itemStr);
        


        for (int i=0; i<jsonArray.length();i++){
            AreaCodeVO sigunguVO = new AreaCodeVO();
            JSONObject jsonObject45=jsonArray.getJSONObject(i);
            sigunguVO.setName(areaCodeVO.getName());
            sigunguVO.setCode(areaCodeVO.getCode());
            sigunguVO.setSigunguCode(jsonObject45.getInt("code"));
            sigunguVO.setSigunguName(jsonObject45.getString("name"));
//            Log.i("test", "SigunguCode :"+jsonObject45.getInt("code"));
//            Log.i("test", "SigunguName :"+jsonObject45.getString("name"));
            areaCodeVOS.add(sigunguVO);

        }
       Log.i("test", "파싱한 데이터 수:"+areaCodeVOS);
//        Log.i("test", "실행후 for문 전 areaCodeVOS : "+areaCodeVOS.size());
        //라디오 버튼 생성
        for(int i=0;i<areaCodeVOS.size();i++){
            RadioButton radioButton = new RadioButton(this);
            radioButton.setText( areaCodeVOS.get(i).getSigunguName());
            radioButton.setId(i);
            RadioGroup.LayoutParams rprms= new RadioGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rgp.addView(radioButton, rprms);

        }


        return areaCodeVOS;



    }
}