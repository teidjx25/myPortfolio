package com.example.myapplication;

import java.io.Serializable;

public class AreaCodeVO implements Serializable {
    private int code;
    private String name;
    private int SigunguCode;
    private String SigunguName;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSigunguName() {
        return SigunguName;
    }

    public void setSigunguName(String sigunguName) {
        SigunguName = sigunguName;
    }

    public int getSigunguCode() {
        return SigunguCode;
    }

    public void setSigunguCode(int sigunguCode) {
        SigunguCode = sigunguCode;
    }

    @Override
    public String toString() {
        return "AreaCodeVO{" +
                "code=" + code +
                ", name='" + name + '\'' +
                ", SigunguCode=" + SigunguCode +
                ", SigunguName='" + SigunguName + '\'' +
                '}';
    }
}
