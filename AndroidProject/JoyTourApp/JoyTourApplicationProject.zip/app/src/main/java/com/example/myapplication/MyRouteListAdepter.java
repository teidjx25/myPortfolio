package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MyRouteListAdepter extends BaseAdapter {
    static RequestQueue requestQueue;
    private LayoutInflater inflater;
    MyRouteListAdepter myRouteListAdepter;
    Context con;
    private int layout;
    private ArrayList<routeNameVO> data;
    TextView RouteListTitle;
    Button routeDelBtn;


    public MyRouteListAdepter(Context context, int layout, ArrayList<routeNameVO> data){
        con=context;
        this.inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.data=data;
        this.layout=layout;
    }
    @Override
    public int getCount(){return data.size();}

    @Override
    public Object getItem(int position) {
        return data.get(position).getRouteName();
    }

    @Override
    public long getItemId(int position){return position;}
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView==null){
            convertView=inflater.inflate(layout,parent,false);
        }
        if(requestQueue==null){
            requestQueue= Volley.newRequestQueue(con.getApplicationContext());
        }

        routeDelBtn = convertView.findViewById(R.id.routeDelBtn);
        RouteListTitle = (TextView)convertView.findViewById(R.id.RouteListTitle);
        routeNameVO routeVO= data.get(position);
        RouteListTitle.setText(routeVO.getRouteName());
        RouteListTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(con,RouteDetail.class);
                intent.putExtra("id",routeVO.getRouteName());
                con.startActivity(intent);

            }
        });

        routeDelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteRequest(routeVO.getRouteName());
            }
        });
        return convertView;
    }
    public void DeleteRequest(String id){
        String url="http://180.68.74.33:8090/Event/deleteRouteInfo?id="+id;

        StringRequest request=new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {

                        //println("응답 ->" + response);
                        Toast.makeText(con.getApplicationContext(), response, Toast.LENGTH_LONG).show();
                        for(int i=0; i<data.size();i++){

                            //루트 아이디가 같으면 삭제
                           if (id.equals(data.get(i).getRouteName())) {
                                data.remove(i);
                                myRouteListAdepter.notifyDataSetChanged();
                           }

                        }


                        //processResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // println("에러 ->" + error.getMessage());
                    }
                }
        ){ @Override //response를 UTF8로 변경해주는 소스코드
        protected Response<String> parseNetworkResponse(NetworkResponse response) {
            try {
                String utf8String = new String(response.data, "UTF-8");
                return Response.success(utf8String, HttpHeaderParser.parseCacheHeaders(response));
            } catch (UnsupportedEncodingException e) {
                // log error
                return Response.error(new ParseError(e));
            } catch (Exception e) {
                // log error
                return Response.error(new ParseError(e));
            }
        }
            protected Map<String,String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String,String>();

                return params;
            }
        };
        request.setShouldCache(false);
        requestQueue.add(request);
        //  println("요청보냄");
    }

}
