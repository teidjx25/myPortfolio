package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class RouteDatailAdepter extends BaseAdapter {

    static RequestQueue requestQueue;
    private LayoutInflater inflater;
    private ArrayList<RouteVO> data;
    private int layout;
    Context con;
    String dateInfo;
    Button btnDelete;
    ImageButton imageButtonItem;
    TextView tvTitle,tvAddr1,tvEventDate;


    public RouteDatailAdepter(Context context, int layout, ArrayList<RouteVO> data){
        con=context;
        this.inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.data=data;
        this.layout=layout;
    }


    @Override
    public int getCount(){return data.size();}

    @Override
    public Object getItem(int position) {
        return data.get(position).getTitle();
    }

    @Override
    public long getItemId(int position){return position;}

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView==null){
            convertView=inflater.inflate(layout,parent,false);
        }
        RouteVO routeVO=data.get(position);
        btnDelete =convertView.findViewById(R.id.btnDelete123);
        imageButtonItem =convertView.findViewById(R.id.imageButtonItem);
        tvTitle =convertView.findViewById(R.id.tvTitle);
        tvAddr1 =convertView.findViewById(R.id.tvAddr1);
        tvEventDate =convertView.findViewById(R.id.tvEventDate);

        String imageUrl = routeVO.getFirstimage();
        Glide.with(con).load(imageUrl).into(imageButtonItem);
        EventVO eventVO =new EventVO();
        eventVO.setAddr1(routeVO.getAddr1());
        eventVO.setAreacode(routeVO.getAreacode());
        eventVO.setChoiceDate(routeVO.getItemDate());
        eventVO.setContentid(routeVO.getContentid());
        eventVO.setContenttypeid(routeVO.getContenttypeid());
        eventVO.setEventenddate(routeVO.getEventenddate());
        eventVO.setEventstartdate(routeVO.getEventstartdate());
        eventVO.setFirstimage(routeVO.getFirstimage());
        eventVO.setMapx(routeVO.getMapx());
        eventVO.setMapy(routeVO.getMapy());
        eventVO.setReadcount(routeVO.getReadcount());
        eventVO.setRouteid(routeVO.getRouteid());
        eventVO.setSigungucode(routeVO.getSigungucode());
        eventVO.setTel(routeVO.getTel());
        eventVO.setTitle(routeVO.getTitle());

        if (imageUrl==null) {
            imageButtonItem.setImageResource(R.drawable.no_image);
        }
        if(routeVO.getEventstartdate()!=0) {
            //기간 설정

            dateInfo = routeVO.getRouteDate();
            tvEventDate.setVisibility(View.VISIBLE);
            tvEventDate.setText(dateInfo);
            tvAddr1.setText(routeVO.getAddr1());
        }
        tvTitle.setText(routeVO.getTitle());

        imageButtonItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(con,DetailActivity.class);
                intent.putExtra("DetailInfo",eventVO);
                con.startActivity(intent);
            }
        });
        return convertView;
    }
}
