package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class TravelActivity extends AppCompatActivity {


    int TStartDateInfo=0;
    int TEndDateInfo=0;
    String TStartDate="";
    String TEndDate="";
    String bakDate,locainf;
    TextView InfoTv,tvTravelDate,TravelReqInpTv;
    EditText etPersonNum;
    LinearLayout dateInfoLayout,TravelReqInpLO;
    AreaCodeVO areaCodeVO;
    UserSelectVO userSelectVO =new UserSelectVO();
    Boolean Clickedis=false;
    static RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("정보 선택");
        setContentView(R.layout.activity_travel);
        InfoTv =findViewById(R.id.InfoTv);
        tvTravelDate =findViewById(R.id.tvTravelDate);
        etPersonNum =findViewById(R.id.etPersonNum);
        dateInfoLayout =findViewById(R.id.dateInfoLayout);
        TravelReqInpLO =findViewById(R.id.TravelReqInpLO);
        TravelReqInpTv =findViewById(R.id.TravelReqInpTv);
        if(requestQueue==null){
            requestQueue= Volley.newRequestQueue(getApplicationContext());
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==1100 && resultCode == RESULT_OK){
            areaCodeVO=(AreaCodeVO)data.getSerializableExtra("AreaCode");
            Log.i("test2", "TravelActivity nowArea : "+ areaCodeVO);

            InfoTv.setVisibility(View.VISIBLE);
            if (areaCodeVO.getSigunguCode()==9999){

                locainf=areaCodeVO.getName() + "\n 상세 지역 없음";

                if(areaCodeVO==null){
                    locainf=null;
                }
                InfoTv.setText(locainf);
            }else {
                locainf=areaCodeVO.getName() +" "+areaCodeVO.getSigunguName();
                InfoTv.setText(locainf);
            }

        }
    }



    DatePickerDialog.OnDateSetListener StartDateSetListener =

            new DatePickerDialog.OnDateSetListener() {

                @Override

                public void onDateSet(DatePicker datePicker, int yy, int mm, int dd) {

                    // Date Picker에서 선택한 날짜를 TextView에 설정
                    dateInfoLayout.setVisibility(View.VISIBLE);
                    String StartMonth = mm+1<10?"0"+(mm+1):""+(mm+1);
                    String StartDay = dd<10?"0"+dd:""+dd;
                    TStartDate = yy+"/"+StartMonth+"/"+StartDay;
                    TStartDateInfo =Integer.parseInt(yy+StartMonth+StartDay);

                    if ((TEndDateInfo - TStartDateInfo)<=0 || TStartDateInfo==0 || TEndDateInfo==0){
                        bakDate="";
                    }else{
                        bakDate= "\n"+ (TEndDateInfo-TStartDateInfo)+"박 "+(TEndDateInfo-TStartDateInfo+1)+"일 ";
                    }
                    tvTravelDate.setText(TStartDate + "     ~      "+ TEndDate+bakDate);


                }

            };
    DatePickerDialog.OnDateSetListener endDateSetListener =

            new DatePickerDialog.OnDateSetListener() {

                @Override

                public void onDateSet(DatePicker datePicker, int yy, int mm, int dd) {

                    // Date Picker에서 선택한 날짜를 TextView에 설정
                    dateInfoLayout.setVisibility(View.VISIBLE);
                    String EndMonth = mm+1<10?"0"+(mm+1):""+(mm+1);
                    String EndDay = dd<10?"0"+dd:""+dd;
                    TEndDate = yy+"/"+EndMonth+"/"+EndDay;
                    TEndDateInfo= Integer.parseInt(yy+EndMonth+EndDay);
                    if ((TEndDateInfo - TStartDateInfo)<=0 || TStartDateInfo==0 || TEndDateInfo==0){
                        bakDate="";
                    }else{
                        bakDate= "\n"+ (TEndDateInfo-TStartDateInfo)+"박 "+(TEndDateInfo-TStartDateInfo+1)+"일 ";
                    }
                    tvTravelDate.setText(TStartDate + "     ~      "+ TEndDate+bakDate);

                }

            };
    public void TravelActivityClickedBtn(View view){
        Calendar cal = Calendar.getInstance();
        switch(view.getId()){
            case R.id.SelectLocationBtn:
                Intent intent = new Intent(TravelActivity.this, area_Activity.class);
                startActivityForResult(intent, 1100);

                break;
            case R.id.btnStart:
                // DATE Picker가 처음 떴을 때, 오늘 날짜가 보이도록 설정.
                new DatePickerDialog(this, StartDateSetListener, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DATE)).show();

                break;
            case R.id.btnEnd:

                new DatePickerDialog(this, endDateSetListener, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DATE)).show();


                break;

            case R.id.SaveBtn:
                Log.i("test", "TStartDateInfo : "+ TStartDateInfo+" TEndDateInfo : "+TEndDateInfo);
                Log.i("test", "TStartDateInfo : "+ (TEndDateInfo - TStartDateInfo));

                if (TEndDateInfo==0 || TStartDateInfo==0){
                    TravelReqInpLO.setVisibility(View.VISIBLE);
                    TravelReqInpTv.setText("여행 시작일자 또는 여행 종료 날짜 중 하나를 선택 안하셨습니다. ");

                    //Log.i("test", " 둘 중 하나를 선택 안하셨습니다. ");
                    break;
                }
                if (locainf==null || locainf.equals("null\n 상세 지역 없음")){
                    TravelReqInpLO.setVisibility(View.VISIBLE);
                    TravelReqInpTv.setText("아직 지역을 선택 안하셨습니다 ");

                    break;
                }
                if (etPersonNum.getText().toString().getBytes().length <= 0){
                    TravelReqInpLO.setVisibility(View.VISIBLE);
                    TravelReqInpTv.setText("아직 인원을 선택 안하셨습니다 ");

                    break;
                }


                if ((TEndDateInfo - TStartDateInfo)<=0 && !(TStartDateInfo==0 || TEndDateInfo==0)){
                    TravelReqInpLO.setVisibility(View.VISIBLE);
                    TravelReqInpTv.setText("여행 끝 날짜는 시작날짜 보다 작을수 없습니다. ");
                   // Log.i("test", " 여행 끝 날짜는 시작날짜 보다 작을수 없습니다. ");
                    break;
                }
                if(!Clickedis){
                    TravelReqInpTv.setText("저장하기를 눌러 주세요");
                    break;
                }
                Intent intent1 =new Intent(this,SearchActivity.class);
                intent1.putExtra("userSelectVO",userSelectVO);
                startActivity(intent1);

                break;
            case R.id.CompleteSelect:
                if (TEndDateInfo==0 || TStartDateInfo==0){
                    TravelReqInpLO.setVisibility(View.VISIBLE);
                    TravelReqInpTv.setText("여행 시작일자 또는 여행 종료 날짜 중 하나를 선택 안하셨습니다. ");

                    //Log.i("test", " 둘 중 하나를 선택 안하셨습니다. ");
                    break;
                }
                if (locainf==null){
                    TravelReqInpLO.setVisibility(View.VISIBLE);
                    TravelReqInpTv.setText("아직 지역을 선택 안하셨습니다 ");

                    break;
                }
                if (etPersonNum.getText().toString().getBytes().length <= 0){
                    TravelReqInpLO.setVisibility(View.VISIBLE);
                    TravelReqInpTv.setText("아직 인원을 선택 안하셨습니다 ");

                    break;
                }


                if ((TEndDateInfo - TStartDateInfo)<=0 && !(TStartDateInfo==0 || TEndDateInfo==0)){
                    TravelReqInpLO.setVisibility(View.VISIBLE);
                    TravelReqInpTv.setText("여행 끝 날짜는 시작날짜 보다 작을수 없습니다. ");
                    // Log.i("test", " 여행 끝 날짜는 시작날짜 보다 작을수 없습니다. ");
                    break;
                }
                TravelReqInpLO.setVisibility(View.VISIBLE);


                String maininf ="여행 장소 :  " + locainf + "\n";
                        maininf += "여행 인원 : " + etPersonNum.getText()+ "\n";
                        maininf += "여행 날짜 : " + TStartDate + "     ~      "+ TEndDate+bakDate ;
                TravelReqInpTv.setText(maininf);


                userSelectVO.setAreaCode(areaCodeVO.getCode());
                userSelectVO.setAreaCodeName(areaCodeVO.getName());
                userSelectVO.setSigunguCode(areaCodeVO.getSigunguCode());
                userSelectVO.setSigunguCodeName(areaCodeVO.getSigunguName());
                userSelectVO.setPersonNum(Integer.parseInt(String.valueOf(etPersonNum.getText())));
                userSelectVO.setStartDate(TStartDateInfo);
                userSelectVO.setEndDate(TEndDateInfo);
                sendmakeRequest();
                Clickedis=true;
                break;

            case R.id.SelectFinish:
                finish();
                break;



        }
    }

    public void sendmakeRequest(){
        String url="http://180.68.74.33:8090/Event/userSelectRegister";
        StringRequest request=new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {

                        println("응답 ->" + response);
                        Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                        //processResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        println("에러 ->" + error.getMessage());
                    }
                }
        ){ @Override //response를 UTF8로 변경해주는 소스코드
        protected Response<String> parseNetworkResponse(NetworkResponse response) {
            try {
                String utf8String = new String(response.data, "UTF-8");
                return Response.success(utf8String, HttpHeaderParser.parseCacheHeaders(response));
            } catch (UnsupportedEncodingException e) {
                // log error
                return Response.error(new ParseError(e));
            } catch (Exception e) {
                // log error
                return Response.error(new ParseError(e));
            }
        }
            protected Map<String,String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String,String>();
                params.put("areaCodeName",userSelectVO.getAreaCodeName());
                params.put("sigunguCodeName",userSelectVO.getSigunguCodeName());
                params.put("areaCode",String.valueOf(userSelectVO.getAreaCode()));
                params.put("sigunguCode",String.valueOf(userSelectVO.getSigunguCode()));
                params.put("personNum",String.valueOf(userSelectVO.getPersonNum()));
                params.put("endDate",String.valueOf(userSelectVO.getEndDate()));
                params.put("StartDate",String.valueOf(userSelectVO.getStartDate()));


                return params;
            }
        };
        request.setShouldCache(false);
        requestQueue.add(request);
        println("요청보냄");
    }
    private void println(String str){
        Log.i("test123", "println: "+str+"\n");
    }
}