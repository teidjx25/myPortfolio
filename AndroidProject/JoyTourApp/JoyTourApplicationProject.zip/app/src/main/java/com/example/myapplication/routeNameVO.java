package com.example.myapplication;

public class routeNameVO {
    private String routeName;
    private int count;


    public String getRouteName() {
        return routeName;
    }

    public void setRouteName(String routeName) {
        this.routeName = routeName;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "routeNameVO{" +
                "routeName='" + routeName + '\'' +
                ", count=" + count +
                '}';
    }
}
