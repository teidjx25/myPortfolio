package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.json.JSONException;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MyRouteList extends AppCompatActivity {
    ListView RouteListView;
    Button btnCancel;

    ArrayList<routeNameVO> routeArrayList =new ArrayList<routeNameVO>();
    static RequestQueue requestQueue;
    MyRouteListAdepter myRouteListAdepter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_route_list);
        setTitle("루트들 조회");
        RouteListView=findViewById(R.id.RouteListView);
        btnCancel=findViewById(R.id.btnCancel);

        if(requestQueue==null){
            requestQueue= Volley.newRequestQueue(getApplicationContext());
        }
        resmakeRequest();

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    public void resmakeRequest(){

        String url="http://180.68.74.33:8090/Event/routeList";

        StringRequest request=new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        println("응답 ->" + response);
                        try {
                            processResponse(response);
                        } catch (JSONException | ParseException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        println("에러 ->" + error.getMessage());
                    }
                }
        ){
            @Override //response를 UTF8로 변경해주는 소스코드
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                try {
                    String utf8String = new String(response.data, "UTF-8");
                    return Response.success(utf8String, HttpHeaderParser.parseCacheHeaders(response));
                } catch (UnsupportedEncodingException e) {
                    // log error
                    return Response.error(new ParseError(e));
                } catch (Exception e) {
                    // log error
                    return Response.error(new ParseError(e));
                }
            }
            protected Map<String,String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String,String>();
                return params;
            }
        };

        request.setShouldCache(false);
        requestQueue.add(request);
        println("요청보냄");
    }
    private void processResponse(String response) throws JSONException, ParseException {


        Gson gson =new Gson();
        routeNameVO[] routeNames=gson.fromJson(response,routeNameVO[].class);
        for(int i=0; i<routeNames.length;i++){

                routeArrayList.add(routeNames[i]);
        }

        println("파싱한 데이터 수 루트:"+routeArrayList.size());



       myRouteListAdepter = new MyRouteListAdepter(this, R.layout.my_route_list_item, routeArrayList);
       RouteListView.setAdapter(myRouteListAdepter);


    }
    private void println(String str){
        Log.i("test123", "println: "+str+"\n");
    }
}