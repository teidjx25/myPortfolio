package com.example.myapplication;

import java.io.Serializable;

public class UserSelectVO implements Serializable {
    private int areaCode;
    private String areaCodeName;

    private int sigunguCode;
    private String sigunguCodeName;

    private int personNum;
    private int startDate;
    private int endDate;

    public int getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(int areaCode) {
        this.areaCode = areaCode;
    }

    public int getSigunguCode() {
        return sigunguCode;
    }

    public void setSigunguCode(int sigunguCode) {
        this.sigunguCode = sigunguCode;
    }

    public int getPersonNum() {
        return personNum;
    }

    public void setPersonNum(int personNum) {
        this.personNum = personNum;
    }

    public int getStartDate() {
        return startDate;
    }

    public void setStartDate(int startDate) {
        this.startDate = startDate;
    }

    public int getEndDate() {
        return endDate;
    }

    public void setEndDate(int endDate) {
        this.endDate = endDate;
    }

    public String getAreaCodeName() {
        return areaCodeName;
    }

    public void setAreaCodeName(String areaCodeName) {
        this.areaCodeName = areaCodeName;
    }

    public String getSigunguCodeName() {
        return sigunguCodeName;
    }

    public void setSigunguCodeName(String sigunguCodeName) {
        this.sigunguCodeName = sigunguCodeName;
    }

    @Override
    public String toString() {
        return "UserSelectVO{" +
                "areaCode=" + areaCode +
                ", areaCodeName='" + areaCodeName + '\'' +
                ", sigunguCode=" + sigunguCode +
                ", sigunguCodeName='" + sigunguCodeName + '\'' +
                ", personNum=" + personNum +
                ", StartDate=" + startDate +
                ", endDate=" + endDate +
                '}';
    }
}
