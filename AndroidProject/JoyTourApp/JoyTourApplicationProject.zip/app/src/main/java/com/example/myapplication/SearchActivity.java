package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SearchActivity extends AppCompatActivity {
    ListView listView;
    String URL = null;
    static RequestQueue requestQueue;
    ListviewAdapter adapterEvent1,adapterLocation1,adapterHotel;
    ArrayList<EventVO> eventVOAL ;
    UserSelectVO userSelectVO;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        Intent intent =getIntent();

        userSelectVO =(UserSelectVO) intent.getSerializableExtra("userSelectVO");
        listView=(ListView)findViewById(R.id.listTour2);
        Log.i("test5", "onCreate: userSelectVO : "+userSelectVO);
        if(requestQueue==null){
            requestQueue= Volley.newRequestQueue(getApplicationContext());
        }
        setTitle("검색 결과");

        try {
            EventReq(1);
            EventReq(2);
            EventReq(3);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //--------------------데이터 받아 오는 메소드-------------------------------------------------------
    private ArrayList<EventVO> resEvent(String response, int Select) throws JSONException {

        ArrayList<EventVO> eventVOArrayList = new ArrayList<EventVO>();
        JSONObject jsonObject = new JSONObject(response);
        String items = jsonObject.getString("response");

        JSONObject resJsonArray = new JSONObject(items);
        String body = resJsonArray.getString("body");
        JSONObject ItemsArray = new JSONObject(body);
        String itemsStr = ItemsArray.getString("items");

        if(itemsStr.equals("")){
            Log.i("test5", "itemStr is null 4");

        }
            Log.i("test", "응답 ->" + itemsStr+"?");
            JSONObject ItemArray = new JSONObject(itemsStr);

            String itemStr = ItemArray.has("item")?ItemArray.getString("item"):null;


            JSONArray jsonArray =new JSONArray(itemStr);
            //Log.i("test3", "jsonArray 실행 ");


            Log.i("test5", "itemStr 실행 "+ itemStr+"입니다");

            for (int i=0; i<jsonArray.length();i++){
                EventVO eventVO = new EventVO();
                JSONObject jsonObject45=jsonArray.getJSONObject(i);



                eventVO.setAddr1(jsonObject45.getString("addr1"));
                eventVO.setAreacode(jsonObject45.getInt("areacode"));
                eventVO.setSigungucode(jsonObject45.getInt("sigungucode"));
                eventVO.setContentid(jsonObject45.getInt("contentid"));
                eventVO.setContenttypeid(jsonObject45.getInt("contenttypeid"));
                eventVO.setEventenddate(0);
                eventVO.setEventstartdate(0);
                eventVO.setTel("");
                if(Select==1) {
                    eventVO.setEventenddate(jsonObject45.getInt("eventenddate"));
                    eventVO.setEventstartdate(jsonObject45.getInt("eventstartdate"));
                    eventVO.setTel(jsonObject45.getString("tel"));

                }

                eventVO.setFirstimage(jsonObject45.has("firstimage")?jsonObject45.getString("firstimage"):null);
                eventVO.setMapx(jsonObject45.getDouble("mapx"));
                eventVO.setMapy(jsonObject45.getDouble("mapy"));
                eventVO.setReadcount(jsonObject45.getInt("readcount"));


                eventVO.setTitle(jsonObject45.getString("title"));



                eventVOArrayList.add(eventVO);

            }

//            for (int i =0; i<10;i++){
//                eventVOArrayList.get(i).setRanking((i+1)+"위");
//                Log.i("test"," "+eventVOArrayList.get(i));
//            }


            Log.i("test5", "eventVOArrayList"+eventVOArrayList.size());

            eventVOAL=eventVOArrayList;
            Log.i("test", "파싱한 데이터 수:"+eventVOArrayList.size());
            Log.i("test2", "파싱한 데이터 수:"+eventVOAL.size());




        // println("파싱한 데이터 수:"+itemStr);
        if(Select==1){
            adapterEvent1=new ListviewAdapter(this,R.layout.mainitem,eventVOAL);
            listView.setAdapter(adapterEvent1);
        }else if(Select==2){
            adapterLocation1=new ListviewAdapter(this,R.layout.mainitem,eventVOAL);
        }else {
            adapterHotel=new ListviewAdapter(this,R.layout.mainitem,eventVOAL);
        }
        return eventVOArrayList;



    }
    public void EventReq(int Select) throws Exception {
        final String serviceKey ="7W%2FcZNCxnT2mBSdPEJtSaa3zDS6Vg7XuBgyW1MTPIoXvi3UgTzb%2Fdo%2F25%2FyXIJKlmADRJ4RcI%2FQst%2FSAHzT89g%3D%3D";

        if(Select==1){
            URL ="http://api.visitkorea.or.kr/openapi/service/rest/KorService/searchFestival";
        }
        if (Select==2) {
            URL ="http://api.visitkorea.or.kr/openapi/service/rest/KorService/areaBasedList";
        }
        if (Select==3) {
            URL ="http://api.visitkorea.or.kr/openapi/service/rest/KorService/searchStay";
        }
        Log.i("test", "현재 URL " + URL);
        int numOfRows=20;
        int pagenum=1;
        //현재 날짜 받아와야 됨

        String startEvent=userSelectVO.getStartDate()+"";
        String areaCode = "&areaCode="+userSelectVO.getAreaCode()+"&sigunguCode="+userSelectVO.getSigunguCode();
        if(userSelectVO.getSigunguCode()==9999){
            areaCode = "&areaCode="+userSelectVO.getAreaCode();
        }
        String eventDate ="&eventStartDate="+startEvent;


        String Option = "?serviceKey="+serviceKey+"&MobileOS=ETC"+"&MobileApp=AppTest&_type=json&numOfRows="+numOfRows+"&pageNo="+pagenum+"&arrange=B"+"&listYN=Y"+eventDate+areaCode;
        Log.i("test5", "areaCode: "+areaCode);
        String strUrl =URL+Option;

        StringRequest request=new StringRequest(Request.Method.GET, strUrl,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        String res=null;
                        res=response;

                        Log.i("test", "응답 ->" + res+"?");
                        try {
                            eventVOAL=resEvent(response,Select);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.i("test", "에러 ->" + error.getMessage());
                    }
                }
        ){
            @Override //response를 UTF8로 변경해주는 소스코드
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                try {
                    String utf8String = new String(response.data, "UTF-8");
                    return Response.success(utf8String, HttpHeaderParser.parseCacheHeaders(response));
                } catch (UnsupportedEncodingException e) {
                    // log error
                    return Response.error(new ParseError(e));
                } catch (Exception e) {
                    // log error
                    return Response.error(new ParseError(e));
                }
            }
            protected Map<String,String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String,String>();
                return params;
            }
        };

        request.setShouldCache(false);
        requestQueue.add(request);
        Log.i("test2", "요청보냄");


    }

    //--------------------------------------------------------------------------------------------------



    //-------------------버튼 셀렉트 함수
    public void btnSelect(View view) throws Exception {
        switch (view.getId()){

            case R.id.btnSEvent:
                listView.setAdapter(adapterEvent1);
                break;

            case R.id.btnSLocation:
                listView.setAdapter(adapterLocation1);
                break;
            case R.id.btnHotel:
                listView.setAdapter(adapterHotel);
                break;
            case R.id.btnPlanComplete:
                Intent intent =new Intent(this,myItemActivity.class);
                startActivity(intent);
                break;
            case R.id.btnBack:
                finish();
                break;
        }
    }


}