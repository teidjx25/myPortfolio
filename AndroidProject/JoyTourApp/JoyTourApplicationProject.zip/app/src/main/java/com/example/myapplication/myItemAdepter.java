package com.example.myapplication;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class myItemAdepter extends BaseAdapter {
    static RequestQueue requestQueue;
    private LayoutInflater inflater;
    private ArrayList<EventVO> data;
    private int layout;
    Context con;
    String dateInfo;
    Button btnDelete,btnDateSelect;
    ImageButton imageButtonItem;
    TextView tvTitle,tvAddr1,tvEventDate;
    int StartTour;
    int TDate=0;
    String TStrDate="";

    myItemAdepter myItemAdepter;

    public myItemAdepter(Context context, int layout, ArrayList<EventVO> data, int StartTour){
        con=context;
        this.inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.data=data;
        this.layout=layout;
        this.StartTour =StartTour;
        myItemAdepter = this;
    }


    @Override
    public int getCount(){return data.size();}

    @Override
    public Object getItem(int position) {
        return data.get(position).getTitle();
    }

    @Override
    public long getItemId(int position){return position;}

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView==null){
            convertView=inflater.inflate(layout,parent,false);
        }
        if(requestQueue==null){
            requestQueue= Volley.newRequestQueue(con.getApplicationContext());
        }
        EventVO eventVO=data.get(position);
        btnDelete =convertView.findViewById(R.id.btnDelete123);
        imageButtonItem =convertView.findViewById(R.id.imageButtonItem);
        tvTitle =convertView.findViewById(R.id.tvTitle);
        tvAddr1 =convertView.findViewById(R.id.tvAddr1);

        btnDateSelect =convertView.findViewById(R.id.btnDateSelect);
        tvEventDate =convertView.findViewById(R.id.tvEventDate);
        String imageUrl = eventVO.getFirstimage();
        Glide.with(con).load(imageUrl).into(imageButtonItem);

        if (imageUrl==null) {
            imageButtonItem.setImageResource(R.drawable.no_image);
        }
        if(eventVO.getEventstartdate()!=0) {
            //기간 설정
            String startDate = eventVO.getEventstartdate() + "";
            String endDate = eventVO.getEventenddate() + "";
            StringBuffer orstartDate = new StringBuffer(startDate);
            orstartDate.insert(4, ".");
            orstartDate.insert(7, ".");
            StringBuffer orendDate = new StringBuffer(endDate);
            orendDate.insert(4, ".");
            orendDate.insert(7, ".");

            dateInfo = orstartDate + "~" + orendDate + "\t";
            tvEventDate.setVisibility(View.VISIBLE);
            tvEventDate.setText(dateInfo);
            tvAddr1.setText(eventVO.getAddr1());
        }

        tvTitle.setText(eventVO.getTitle());
        imageButtonItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(con,DetailActivity.class);
                intent.putExtra("DetailInfo",eventVO);
                con.startActivity(intent);
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteRequest(eventVO.getRouteid());
            }

        });
        DatePickerDialog.OnDateSetListener StartDateSetListener =

                new DatePickerDialog.OnDateSetListener() {

                    @Override

                    public void onDateSet(DatePicker datePicker, int yy, int mm, int dd) {

                        // Date Picker에서 선택한 날짜를 TextView에 설정
                        String StartMonth = mm+1<10?"0"+(mm+1):""+(mm+1);
                        String StartDay = dd<10?"0"+dd:""+dd;
                        TStrDate= yy+"-"+StartMonth+"-"+StartDay;
                        TDate =Integer.parseInt(yy+StartMonth+StartDay);
                        DateUpdateRequest(eventVO.getRouteid(),TDate);
                        Log.i("test123", TStrDate);


                    }

                };
        btnDateSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int year =StartTour/10000;
                int mon =(StartTour%10000)/100;
                int day =StartTour%100;

                new DatePickerDialog(con, StartDateSetListener, year,mon,day).show();
            }
        });


        return convertView;
    }

    public void DeleteRequest(int num){
        String url="http://180.68.74.33:8090/Event/delete?num="+num;
        Log.i("test123", url);
        StringRequest request=new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {

                        //println("응답 ->" + response);
                        Toast.makeText(con.getApplicationContext(), response, Toast.LENGTH_LONG).show();
                        for(int i=0; i<data.size();i++){
                            int num2=data.get(i).getRouteid();
                            //루트 아이디가 같으면 삭제
                            if (num == num2) {
                                data.remove(i);
                            }
                        }

                        myItemAdepter.notifyDataSetChanged();

                        //processResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                       // println("에러 ->" + error.getMessage());
                    }
                }
        ){ @Override //response를 UTF8로 변경해주는 소스코드
        protected Response<String> parseNetworkResponse(NetworkResponse response) {
            try {
                String utf8String = new String(response.data, "UTF-8");
                return Response.success(utf8String, HttpHeaderParser.parseCacheHeaders(response));
            } catch (UnsupportedEncodingException e) {
                // log error
                return Response.error(new ParseError(e));
            } catch (Exception e) {
                // log error
                return Response.error(new ParseError(e));
            }
        }
            protected Map<String,String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String,String>();

                return params;
            }
        };
        request.setShouldCache(false);
        requestQueue.add(request);
      //  println("요청보냄");
    }

    public void DateUpdateRequest(int num,int choiceDate){
        String url="http://180.68.74.33:8090/Event/routeUpdate?routeid="+num+"&choiceDate="+choiceDate;

        StringRequest request=new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {

                        //println("응답 ->" + response);
                        Toast.makeText(con.getApplicationContext(), response, Toast.LENGTH_LONG).show();

                        //processResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // println("에러 ->" + error.getMessage());
                    }
                }
        ){ @Override //response를 UTF8로 변경해주는 소스코드
        protected Response<String> parseNetworkResponse(NetworkResponse response) {
            try {
                String utf8String = new String(response.data, "UTF-8");
                return Response.success(utf8String, HttpHeaderParser.parseCacheHeaders(response));
            } catch (UnsupportedEncodingException e) {
                // log error
                return Response.error(new ParseError(e));
            } catch (Exception e) {
                // log error
                return Response.error(new ParseError(e));
            }
        }
            protected Map<String,String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String,String>();

                return params;
            }
        };
        request.setShouldCache(false);
        requestQueue.add(request);
        //  println("요청보냄");
    }
    //public  savedDater();
}
