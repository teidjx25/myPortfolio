package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class DetailActivity extends FragmentActivity implements OnMapReadyCallback {
    private GoogleMap mMap;
    String URL = null;
    EventVO eventVO;
    TextView tvName,tvTel,tvEtcInfo,tvNetAddress,tvAddress;
    Button finishBtn,SaveBtn,etcInf;
    String Info="";
    ImageView iv;
    static RequestQueue requestQueue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(requestQueue==null){
            requestQueue= Volley.newRequestQueue(getApplicationContext());
        }
        setContentView(R.layout.activity_detail);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        Intent intent =getIntent();
        eventVO =(EventVO) intent.getSerializableExtra("DetailInfo");
        try {
            EventReq();
        } catch (Exception e) {
            e.printStackTrace();
        }
        tvName=findViewById(R.id.tvName);
        tvTel=findViewById(R.id.tvTel);
        tvEtcInfo=findViewById(R.id.tvEtcInfo);
        tvNetAddress=findViewById(R.id.tvNetAddress);
        tvAddress=findViewById(R.id.tvAddress);
        finishBtn=findViewById(R.id.finishBtn);
        SaveBtn=findViewById(R.id.savedBtn);
        etcInf=findViewById(R.id.etcInf);
        iv=findViewById(R.id.ivContent);

        tvName.setText( eventVO.getTitle());
        tvTel.setText("전화번호 : " +eventVO.getTel());
        tvNetAddress.setText("");
        tvAddress.setText("주소 : " +eventVO.getAddr1());
        String imageUrl = eventVO.getFirstimage();
        Glide.with(this).load(imageUrl).into(iv);
        if (imageUrl==null) {
            iv.setImageResource(R.drawable.no_image);
        }
        tvNetAddress.setText("조회수 : "+eventVO.getReadcount() );


        finishBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        SaveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendmakeRequest();
            }
        });

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // Add a marker in Sydney and move the camera
        Log.i("test", "mapx : "+String.format("%.5f",eventVO.getMapx())+"mapx : "+Double.parseDouble(String.format("%.5f",eventVO.getMapy())));
        LatLng mapx = new LatLng(Double.parseDouble(String.format("%.5f",eventVO.getMapy())),Double.parseDouble(String.format("%.5f",eventVO.getMapx())));
        mMap.addMarker(new MarkerOptions().position(mapx).title(eventVO.getTitle()));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(mapx,15));
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
    public void sendmakeRequest(){
        String url="http://180.68.74.33:8090/Event/androidRegister";
        StringRequest request=new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {

                        println("응답 ->" + response);
                        Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                        //processResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        println("에러 ->" + error.getMessage());
                    }
                }
        ){ @Override //response를 UTF8로 변경해주는 소스코드
        protected Response<String> parseNetworkResponse(NetworkResponse response) {
            try {
                String utf8String = new String(response.data, "UTF-8");
                return Response.success(utf8String, HttpHeaderParser.parseCacheHeaders(response));
            } catch (UnsupportedEncodingException e) {
                // log error
                return Response.error(new ParseError(e));
            } catch (Exception e) {
                // log error
                return Response.error(new ParseError(e));
            }
        }
            protected Map<String,String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String,String>();
                params.put("addr1",eventVO.getAddr1());
                params.put("firstimage",eventVO.getFirstimage());
                params.put("areacode",String.valueOf(eventVO.getAreacode()));
                params.put("sigungucode",String.valueOf(eventVO.getSigungucode()));
                params.put("contentid",String.valueOf(eventVO.getContentid()));
                params.put("contenttypeid",String.valueOf(eventVO.getContenttypeid()));
                params.put("eventstartdate",String.valueOf(eventVO.getEventstartdate()));
                params.put("eventenddate",String.valueOf(eventVO.getEventenddate()));
                params.put("mapx",String.valueOf(eventVO.getMapx()));
                params.put("mapy",String.valueOf(eventVO.getMapy()));
                params.put("readcount",String.valueOf(eventVO.getReadcount()));
                params.put("tel",eventVO.getTel());
                params.put("title",eventVO.getTitle());

                return params;
            }
        };
        request.setShouldCache(false);
        requestQueue.add(request);
        println("요청보냄");
    }
    public void resmakeRequest(){
        String url="http://180.68.74.33:8090/board/listBody";
        StringRequest request=new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        //println("응답 ->" + response);
                        try {
                            processResponse(response);
                        } catch (JSONException | ParseException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        println("에러 ->" + error.getMessage());
                    }
                }
        ){
            protected Map<String,String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String,String>();
                return params;
            }
        };

        request.setShouldCache(false);
        requestQueue.add(request);
        println("요청보냄");
    }
    private void resEvent(String response) throws JSONException {

        JSONObject jsonObject = new JSONObject(response);
        String items = jsonObject.getString("response");
        JSONObject resJsonArray = new JSONObject(items);
        String body = resJsonArray.getString("body");
        JSONObject ItemsArray = new JSONObject(body);
        String itemsStr = ItemsArray.getString("items");
        JSONObject ItemArray = new JSONObject(itemsStr);
        String itemStr = ItemArray.getString("item");

        JSONArray jsonArray =new JSONArray(itemStr);
        //Log.i("test3", "jsonArray 실행 ");

        for (int i=0; i<jsonArray.length();i++) {
            JSONObject jsonObject45 = jsonArray.getJSONObject(i);
            InfoPrintln("<" + jsonObject45.getString("infoname")+">");
            InfoPrintln( ""+jsonObject45.getString("infotext"));

            Log.i("test3", "Info: "+Info);
        }


        if(eventVO.getContenttypeid()==15) {

        }else{
            InfoPrintln("해당 타입 아님");
        }
//        for (int i=0; i<jsonArray.length();i++){
//            JSONObject jsonObject45=jsonArray.getJSONObject(i);
//            jsonObject45.getString("addr1");
//        }



    }
    public void EventReq() throws Exception {

        final String serviceKey ="7W%2FcZNCxnT2mBSdPEJtSaa3zDS6Vg7XuBgyW1MTPIoXvi3UgTzb%2Fdo%2F25%2FyXIJKlmADRJ4RcI%2FQst%2FSAHzT89g%3D%3D";

        String contentId= "&contentId="+eventVO.getContentid();
        String contentTypeId="&contentTypeId="+ eventVO.getContenttypeid();
        URL = "http://api.visitkorea.or.kr/openapi/service/rest/KorService/detailInfo";
        String Option = "?serviceKey="+serviceKey+"&MobileOS=ETC"+"&MobileApp=AppTest"+contentId+contentTypeId+"&_type=json";
        String strUrl =URL+Option;


        StringRequest request=new StringRequest(Request.Method.GET, strUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        Log.i("test3", "응답???");
//                        Log.i("test3", "응답 ->" + response);
                        try {
                            resEvent(response);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.i("test", "에러 ->" + error.getMessage());
                    }
                }
        ){
            @Override //response를 UTF8로 변경해주는 소스코드
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                try {
                    String utf8String = new String(response.data, "UTF-8");
                    return Response.success(utf8String, HttpHeaderParser.parseCacheHeaders(response));
                } catch (UnsupportedEncodingException e) {
                    // log error
                    return Response.error(new ParseError(e));
                } catch (Exception e) {
                    // log error
                    return Response.error(new ParseError(e));
                }
            }
            protected Map<String,String> getParams() throws AuthFailureError {
                Map<String, String> params=new HashMap<String,String>();
                return params;
            }
        };

        request.setShouldCache(false);
        requestQueue.add(request);
        Log.i("test2", "요청보냄");


    }
    private void processResponse(String response) throws JSONException, ParseException {



        Gson gson =new Gson();
        EventVO[] eventVOS=gson.fromJson(response,EventVO[].class);
        for(int i=0; i<eventVOS.length;i++){
            println(eventVOS[i].toString());
        }
        println(""+eventVOS.length);
    }
    private void println(String str){
        Log.i("test", "println: "+str+"\n");
    }
    private void InfoPrintln(String str){
        Info +=str+"\n";
        Log.i("test3", "Info메서드: "+Info);


    }
    public void intMet(View view){
        if(view.getId()==R.id.etcInf){

            tvEtcInfo.setText(Info);
            if(Info.equals("")){
                tvEtcInfo.setText("게시된 정보가 없습니다");
            }
        }
    }

}