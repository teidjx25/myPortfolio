package com.example.myapplication;

public class Listviewitem {

    private String Title;
    private int ImageView;
    private String Location;

    public Listviewitem(String title, int imageView, String location) {
        Title = title;
        ImageView = imageView;
        Location = location;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public int getImageView() {
        return ImageView;
    }

    public void setImageView(int imageView) {
        ImageView = imageView;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }
}
