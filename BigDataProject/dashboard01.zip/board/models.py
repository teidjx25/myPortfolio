from django.db import models
from datetime import datetime

# Create your models here.
class Board(models.Model):
    idx=models.AutoField(primary_key=True) #프라이머리키
    writer=models.CharField(null=False, max_length=50) #글자는 50자까지 적겠다는 말
    title=models.CharField(null=False, max_length=200)
    content=models.TextField(null=False) #글자가 좀 크니까 TextField를 사용한다.
    hit=models.IntegerField(default=0) #
    post_date=models.DateTimeField(default=datetime.now, blank=True)
    filename=models.CharField(null=True, blank=True, default='', max_length=500)
    filesize=models.IntegerField(default=0)
    down=models.IntegerField(default=0) #다운로드 몇번했는가
    
   #개시물 조회수 몇번증가 했는가
   #자동 증가하도록 함수 만들어준다.
   #함수호출하면 자동증가하도록 만들어준다.
    def hit_up(self): 
        self.hit+=1 
        
    def down_up(self):
        self.down+=1
        
class Comment(models.Model): #댓글테이블
    idx=models.AutoField(primary_key=True)
    board_idx=models.IntegerField(null=False) #게시물에는 board_idx가 있어야 누구댓글인지 알수가 있다.
        #반드시 게시물번호가 있어야 한다.

    writer=models.CharField(null=False, max_length=50)
    content=models.TextField(null=False)
    post_date=models.DateTimeField(default=datetime.now, blank=True)

# Create your models here.

#필요없으면 지우기
class Gu(models.Model):
    gu=models.CharField(null=False, max_length=5, primary_key=True)
    name=models.CharField(null=False, max_length=10)

#필요없으면 지우기
class Type(models.Model):
    type=models.CharField(null=False, max_length=5, primary_key=True)
    name=models.CharField(null=False, max_length=10)

#위에꺼 안쓰면 fk 지우기
class Data(models.Model): 
    gu=models.ForeignKey(Gu, on_delete=models.CASCADE)
    type=models.ForeignKey(Type, on_delete=models.CASCADE)
    num=models.FloatField(default=1)
    lat=models.FloatField(null=True)
    long=models.FloatField(null=True)

    
#결과필드 추가 (각자 필요한 것 추가하시면 될 것 같습니다)
class Grade(models.Model):
    gu_id=models.CharField(null=False, max_length=5, primary_key=True)
    score=models.FloatField(null=True)
    grade=models.FloatField(null=True)
    crime=models.FloatField(null=True)
    cctv=models.FloatField(null=True)
    cctv2=models.FloatField(null=True)
    
class Average(models.Model):
    score=models.FloatField(null=False, primary_key=True)
    crime=models.FloatField(null=True)
    cctv=models.FloatField(null=True)
    cctv2=models.FloatField(null=True)