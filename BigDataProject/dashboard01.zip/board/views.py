from django.shortcuts import render,redirect
from board.models import Board
from board import bigdataPro
import csv
from board.models import Gu, Data, Type, Grade, Average
from numpy import sum, integer
import folium
from folium import plugins
import os
import pandas as pd


UPLOAD_DIR='c:/hj/upload/'

def main(request):
    return render(request, 'main.html')


# Create your views here.
def list(request):
    boardCount=Board.objects.count() # 게시물 개수 #전체 개수를 얻을 수 있음
    boardList=Board.objects.all().order_by('-idx') #게시물 인덱스별로 -idx 내림차순 정렬 // idx오름차순 (-없으면)
    return render(request, "board/list1.html",{'boardList':boardList, 'boardCount':boardCount})
        #board/list1.html로 전달할 값을 뒤에 적어준다.


def cctv_map (request):
     bigdataPro.cctv_map()
     return render(request, 'map/map01.html')
 

def map (request):
    popup=[]
    data_lat_log=[]
    a_path='c:/hj/upload/' 
    df=pd.read_csv(os.path.join(a_path,'CCTV_20190917.csv'),encoding='utf-8')
    
    for data in df.values:
        if data[4]>0: #설치대수
            popup.append(data[1]) #도로명주소
            data_lat_log.append([data[10],data[11]])
            
    m=folium.Map([35.1646794,129.0568825],zoom_start=15)
    plugins.MarkerCluster(data_lat_log, popups=popup).add_to(m)

    m=m._repr_html_() #updated
    context = {'my_map': m}

    return render(request, 'map.html', context)

def result (request):
    return render(request, 'result.html')
 

def db(request):
    return render(request, 'db.html')

def map_test(request):
    return render(request, 'map_test.html')

def gu_insert(request):
    CSV_PATH=UPLOAD_DIR+'gungu.csv'
    with open(CSV_PATH, encoding='UTF-8') as csvfile:
        data = csv.reader(csvfile, delimiter=',')
        for row in data:
            dto=Gu(gu=row[1],name=row[0])
            dto.save()
    print('gu insert 끝')
    return redirect('/')

#csv파일에서 추가,삭제,수정하셔도 됩니다
def type_insert(request):
    CSV_PATH=UPLOAD_DIR+'type.csv'
    with open(CSV_PATH, encoding='UTF-8') as csvfile:
        data = csv.reader(csvfile, delimiter=',')
        for row in data:
            dto=Type(type=row[0],name=row[1])
            dto.save()
    print('type insert 끝')
    return redirect('/')

def cctv_insert(request):
    CSV_PATH=UPLOAD_DIR+'cctv.csv'
    with open(CSV_PATH, encoding='UTF-8') as csvfile:
        data = csv.reader(csvfile, delimiter=',')
        for row in data:
            if row[0]=='중구':
                code='21010'
            elif row[0]=='서구':
                code='21020'
            elif row[0]=='동구':
                code='21030'
            elif row[0]=='영도구':
                code='21040'
            elif row[0]=='부산진구':
                code='21050'
            elif row[0]=='동래구':
                code='21060'
            elif row[0]=='남구':
                code='21070'
            elif row[0]=='북구':
                code='21080'
            elif row[0]=='해운대구':
                code='21090'
            elif row[0]=='사하구':
                code='21100'
            elif row[0]=='금정구':
                code='21110'
            elif row[0]=='강서구':
                code='21120'
            elif row[0]=='연제구':
                code='21130'
            elif row[0]=='수영구':
                code='21140'
            elif row[0]=='사상구':
                code='21150'
            elif row[0]=='기장군':
                code='21310'
               
            dto=Data(lat=row[3],long=row[4],num=row[2],type_id='d01',gu_id=code)
            dto.save()
    print('cctv insert 끝')
    return redirect('/')

def securitylight_insert(request):
    CSV_PATH=UPLOAD_DIR+'SecurityLight.csv'
    with open(CSV_PATH, encoding='UTF-8') as csvfile:
        data = csv.reader(csvfile, delimiter=',')
        next(data)
        for row in data:
            if row[0]=='중구':
                code='21010'
            elif row[0]=='서구':
                code='21020'
            elif row[0]=='동구':
                code='21030'
            elif row[0]=='영도구':
                code='21040'
            elif row[0]=='부산진구':
                code='21050'
            elif row[0]=='동래구':
                code='21060'
            elif row[0]=='남구':
                code='21070'
            elif row[0]=='북구':
                code='21080'
            elif row[0]=='해운대구':
                code='21090'
            elif row[0]=='사하구':
                code='21100'
            elif row[0]=='금정구':
                code='21110'
            elif row[0]=='강서구':
                code='21120'
            elif row[0]=='연제구':
                code='21130'
            elif row[0]=='수영구':
                code='21140'
            elif row[0]=='사상구':
                code='21150'
            elif row[0]=='기장군':
                code='21310'
                
            if row[3]=='' or row[4]=='':
                dto=Data(gu_id=code,type_id='d02')
                dto.save()  
            else:
                dto=Data(lat=row[3],long=row[4],gu_id=code,type_id='d02')
                dto.save()
                
            #dto=Data(lat=row[3],long=row[4],gu_id=code,type_id='d02')
            #dto.save()    
    print('securitylight insert 끝')
    return redirect('/')

def bell_insert(request):
    CSV_PATH=UPLOAD_DIR+'bell.csv'
    with open(CSV_PATH, encoding='UTF-8') as csvfile:
        data = csv.reader(csvfile, delimiter=',')
        next(data)
        for row in data:
            if row[0]=='중구':
                code='21010'
            elif row[0]=='서구':
                code='21020'
            elif row[0]=='동구':
                code='21030'
            elif row[0]=='영도구':
                code='21040'
            elif row[0]=='부산진구':
                code='21050'
            elif row[0]=='동래구':
                code='21060'
            elif row[0]=='남구':
                code='21070'
            elif row[0]=='북구':
                code='21080'
            elif row[0]=='해운대구':
                code='21090'
            elif row[0]=='사하구':
                code='21100'
            elif row[0]=='금정구':
                code='21110'
            elif row[0]=='강서구':
                code='21120'
            elif row[0]=='연제구':
                code='21130'
            elif row[0]=='수영구':
                code='21140'
            elif row[0]=='사상구':
                code='21150'
            elif row[0]=='기장군':
                code='21310'
                
            dto=Data(lat=row[1],long=row[2],gu_id=code,type_id='d03')
            dto.save()    
    print('bell insert 끝')
    return redirect('/')

 
def bar_insert(request):
    CSV_PATH=UPLOAD_DIR+'bar.csv'
    with open(CSV_PATH, encoding='UTF-8') as csvfile:
        data = csv.reader(csvfile, delimiter=',')
        next(data)
        for row in data:
            if '중구' in row[2]:
                code='21010'
            elif '서구' in row[2]:
                code='21020'
            elif '동구' in row[2]:
                code='21030'
            elif '영도구' in row[2]:
                code='21040'
            elif '부산진구' in row[2]:
                code='21050'
            elif '동래구' in row[2]:
                code='21060'
            elif '남구' in row[2]:
                code='21070'
            elif '북구' in row[2]:
                code='21080'
            elif '해운대구' in row[2]:
                code='21090'
            elif '사하구' in row[2]:
                code='21100'
            elif '금정구' in row[2]:
                code='21110'
            elif '강서구' in row[2]:
                code='21120'
            elif '연제구' in row[2]:
                code='21130'
            elif '수영구' in row[2]:
                code='21140'
            elif '사상구' in row[2]:
                code='21150'
            elif '기장군' in row[2]:
                code='21310'
            
            if row[6]=='':
                dto=Data(gu_id=code,type_id='d04')
                dto.save()
            elif row[6]!='':
                dto=Data(lat=row[6],long=row[7],gu_id=code,type_id='d04')
                dto.save()
   
    print('bar insert 끝')
    return redirect('/')    
    


def police_station_insert(request):
    CSV_PATH=UPLOAD_DIR+'police.csv'
    with open(CSV_PATH, encoding='UTF-8') as csvfile:
        data = csv.reader(csvfile, delimiter=',')
        next(data)
        for row in data:
            if row[6]=='중구':
                code='21010'
            elif row[6]=='서구':
                code='21020'
            elif row[6]=='동구':
                code='21030'
            elif row[6]=='영도구':
                code='21040'
            elif row[6]=='부산진구':
                code='21050'
            elif row[6]=='동래구':
                code='21060'
            elif row[6]=='남구':
                code='21070'
            elif row[6]=='북구':
                code='21080'
            elif row[6]=='해운대구':
                code='21090'
            elif row[6]=='사하구':
                code='21100'
            elif row[6]=='금정구':
                code='21110'
            elif row[6]=='강서구':
                code='21120'
            elif row[6]=='연제구':
                code='21130'
            elif row[6]=='수영구':
                code='21140'
            elif row[6]=='사상구':
                code='21150'
            elif row[6]=='기장군':
                code='21310'
                
            dto=Data(lat=row[4],long=row[3],gu_id=code,type_id='d05')
            dto.save()    
    print('police_station insert 끝')
    return redirect('/')    

def data2019_insert(request):
    CSV_PATH=UPLOAD_DIR+'data_2019.csv'
    with open(CSV_PATH, encoding='UTF-8') as csvfile:
        data = csv.reader(csvfile, delimiter=',')
        next(data)
        for row in data:
            if row[1]=='중구':
                code='21010'
            elif row[1]=='서구':
                code='21020'
            elif row[1]=='동구':
                code='21030'
            elif row[1]=='영도구':
                code='21040'
            elif row[1]=='부산진구':
                code='21050'
            elif row[1]=='동래구':
                code='21060'
            elif row[1]=='남구':
                code='21070'
            elif row[1]=='북구':
                code='21080'
            elif row[1]=='해운대구':
                code='21090'
            elif row[1]=='사하구':
                code='21100'
            elif row[1]=='금정구':
                code='21110'
            elif row[1]=='강서구':
                code='21120'
            elif row[1]=='연제구':
                code='21130'
            elif row[1]=='수영구':
                code='21140'
            elif row[1]=='사상구':
                code='21150'
            elif row[1]=='기장군':
                code='21310'

            dto=Data(gu_id=code,num=row[5],type_id='d06') #경찰공무원
            dto.save()
            dto=Data(gu_id=code,num=row[2],type_id='d07') #인구
            dto.save()
            dto=Data(gu_id=code,num=row[6],type_id='d08') #유동인구
            dto.save()
            dto=Data(gu_id=code,num=row[3],type_id='d09') #다문화
            dto.save()
            dto=Data(gu_id=code,num=row[4],type_id='d10') #저소득한부모
            dto.save()
            dto=Data(gu_id=code,num=row[7],type_id='d11') #도시면적
            dto.save()
            dto=Data(gu_id=code,num=row[8],type_id='d12') #음주율
            dto.save()
            dto=Data(gu_id=code,num=row[9],type_id='d13') #스트레스
            dto.save()
            
            dto=Data(gu_id=code,num=row[10],type_id='c01') #살인
            dto.save()
            dto=Data(gu_id=code,num=row[11],type_id='c02') #강도
            dto.save()
            dto=Data(gu_id=code,num=row[12],type_id='c03') #성범죄
            dto.save()
            dto=Data(gu_id=code,num=row[13],type_id='c04') #절도
            dto.save()
            dto=Data(gu_id=code,num=row[14],type_id='c05') #폭력
            dto.save()
            
            dto=Data(gu_id=code,num=row[16],type_id='d14') #안전지수
            dto.save()
            dto=Data(gu_id=code,num=row[17],type_id='d15') #안전등급
            dto.save()
    print('data2019 insert 끝')
    return redirect('/')


def grade_insert(request):
    CSV_PATH=UPLOAD_DIR+'grade.csv'
    with open(CSV_PATH, encoding='UTF-8') as csvfile:
        data = csv.reader(csvfile, delimiter=',')
        for row in data:
            dto=Grade(gu_id=row[0],score=row[1],grade=row[2],crime=row[3],cctv=row[4],cctv2=row[5])
            dto.save()
    print('grade insert 끝')
    return redirect('/')

def average_insert(request):
    CSV_PATH=UPLOAD_DIR+'average.csv'
    with open(CSV_PATH, encoding='UTF-8') as csvfile:
        data = csv.reader(csvfile, delimiter=',')
        for row in data:
            dto=Average(score=row[0],crime=row[1],cctv=row[2],cctv2=row[3])
            dto.save()
    print('average insert 끝')
    return redirect('/')

def test(request):
#    data1=list(Grade.objects.values('gu').filter(grade='1'))
#    data2=list(Grade.objects.values('gu').filter(grade='2'))
#    data5=list(Grade.objects.values('gu').filter(grade='5'))
#    data4=list(Grade.objects.values('gu').filter(grade='4'))
    
    return render(request, 'sample.html')