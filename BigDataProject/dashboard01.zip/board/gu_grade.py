'''
Created on 2021. 3. 22.

@author: user
'''
import requests
from bs4 import BeautifulSoup
from matplotlib import font_manager,rc
import matplotlib.pyplot as plt
import os
from dashboard01.settings import STATIC_DIR,TEMPLATE_DIR
import pandas as pd
import folium
from folium import plugins
import pytagcloud
from konlpy.tag._okt import Okt
from collections import Counter
from board.models import Gu, Data, Type, Average, Grade
from django.shortcuts import render
from sqlalchemy import create_engine
import matplotlib.pyplot as plt
from matplotlib import font_manager, rc
import matplotlib



def result (request):
    
    # try:
    #
        # gu=request.GET['gu_id']
        # #gu=21020;
        # print('성공')
        # print(gu)
    # except:
        # gu=21010;
        # print('실패')
    data=list(Data.objects.values('num').filter(gu_id=21010,type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21010',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu_id='21010'))
    data7=list(Grade.objects.values('cctv').filter(gu_id='21010'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu_id='21010'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    

    
    
    # 2번코드s

    # data=list(Data.objects.values('num').filter(gu_id=gu,type_id='d14'))
    # data2=list(Data.objects.values('num').annotate().filter(gu_id=gu,type_id='d15'))
    # engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    # conn=engine.connect()
    # data3=pd.read_sql_table('board_grade',conn)
    # data4=list(Average.objects.values('crime').filter(score='1'))
    # data5=list(Average.objects.values('cctv').filter(score='1'))
    # data6=list(Grade.objects.values('crime').filter(gu_id=gu))
    # data7=list(Grade.objects.values('cctv').filter(gu_id=gu))
    # data8=pd.read_sql_table('board_average',conn)
    # data9=list(Average.objects.values('cctv2').filter(score='1'))
    # data10=list(Grade.objects.values('cctv2').filter(gu_id=gu))
    # print(1)
    # return render(request,'gu/gu_21010.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})
    
    
    #그래프
    #data4=pd.read_sql_table('project_average',conn)
    # font_location = "c:/Windows/fonts/malgun.ttf"
    # font_name = font_manager.FontProperties(fname=font_location).get_name()
    # matplotlib.rc('font', family=font_name)
    #
    # fig, ax = plt.subplots(2, 1, figsize=(12,12))
    # ax[0].scatter(data3.gu_id, data3.grade, marker='o', label='안전등급', c='black')
    # ax[0].set_yticks([1,2,3,4,5])
    # ax[0].set_title('예측안전등급', fontsize=20)
    # ax[0].invert_yaxis()
    # ax[0].scatter(gu,data3.loc[14].grade,c='magenta',s=350)
    #
    # ax[1].bar(data3.gu_id,data3.score)
    # ax[1].set_title("예측안전지수", fontsize=20)    
    # fig.savefig(os.path.join(STATIC_DIR,'images/21010.png'),dpi=600)
    # #bigdataPro.makeGraph(df.title, df.point_avg)
    # plt.figure(figsize=(12,12))
    # plt.barh(data3.loc[14].gu_id,data3.loc[14].cctv2,height=0.6)
    # plt.barh(data8.loc[0].score,data8.loc[0].cctv2,height=0.6)
    # #plt.xlabel("")
    # #plt.ylabel("")
    # plt.title("testfile", fontsize=20)
    # plt.savefig(os.path.join(STATIC_DIR,'images/21010_2.png'),dpi=600)
    
   
    
    
    
    
    
    
    
    return render(request, 'result.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})






def gu_21010(request): #중구
    gu=request.GET['fu_id']
    data=list(Data.objects.values('num').filter(gu_id='21010',type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21010',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu='중구'))
    data7=list(Grade.objects.values('cctv').filter(gu='중구'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu='중구'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    
    fig, ax = plt.subplots(2, 1, figsize=(12,12))
    ax[0].scatter(data3.gu, data3.grade, marker='o', label='안전등급', c='black')
    ax[0].set_yticks([1,2,3,4,5])
    ax[0].set_title('예측안전등급', fontsize=20)
    ax[0].invert_yaxis()
    ax[0].scatter('중구',data3.loc[14].grade,c='magenta',s=350)
    
    ax[1].bar(data3.gu,data3.score)
    ax[1].set_title("예측안전지수", fontsize=20)    
    fig.savefig(os.path.join(STATIC_DIR,'images/21010.png'),dpi=600)
    #bigdataPro.makeGraph(df.title, df.point_avg)
    plt.figure(figsize=(12,12))
    plt.barh(data3.loc[14].gu,data3.loc[14].cctv2,height=0.6)
    plt.barh(data8.loc[0].score,data8.loc[0].cctv2,height=0.6)
    #plt.xlabel("")
    #plt.ylabel("")
    plt.title("testfile", fontsize=20)
    plt.savefig(os.path.join(STATIC_DIR,'images/21010_2.png'),dpi=600)
    
    return render(request,'gu/gu_21010.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})

def gu_21020(request): #서구
    data=list(Data.objects.values('num').filter(gu_id='21020',type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21020',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu='서구'))
    data7=list(Grade.objects.values('cctv').filter(gu='서구'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu='서구'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    
    fig, ax = plt.subplots(2, 1, figsize=(12,12))
    ax[0].scatter(data3.gu, data3.grade, marker='o', label='안전등급', c='black')
    ax[0].set_yticks([1,2,3,4,5])
    ax[0].set_title('예측안전등급', fontsize=20)
    ax[0].invert_yaxis()
    ax[0].scatter('서구',data3.loc[10].grade,c='magenta',s=350)
    
    ax[1].bar(data3.gu,data3.score)
    ax[1].set_title("예측안전지수", fontsize=20)    
    fig.savefig(os.path.join(STATIC_DIR,'images/21020.png'),dpi=600)
    #bigdataPro.makeGraph(df.title, df.point_avg)
    plt.figure(figsize=(12,12))
    plt.barh(data3.loc[10].gu,data3.loc[10].cctv,height=0.6)
    plt.barh(data8.loc[0].score,data8.loc[0].cctv,height=0.6)
    #plt.xlabel("")
    #plt.ylabel("")
    plt.title("testfile", fontsize=20)
    plt.savefig(os.path.join(STATIC_DIR,'images/21020_2.png'),dpi=600)
    
    return render(request,'gu/gu_21020.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})

def gu_21030(request): #동구
    data=list(Data.objects.values('num').filter(gu_id='21030',type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21030',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu='동구'))
    data7=list(Grade.objects.values('cctv').filter(gu='동구'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu='동구'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    
    fig, ax = plt.subplots(2, 1, figsize=(12,12))
    ax[0].scatter(data3.gu, data3.grade, marker='o', label='안전등급', c='black')
    ax[0].set_yticks([1,2,3,4,5])
    ax[0].set_title('예측안전등급', fontsize=20)
    ax[0].invert_yaxis()
    ax[0].scatter('동구',data3.loc[4].grade,c='magenta',s=350)
    
    ax[1].bar(data3.gu,data3.score)
    ax[1].set_title("예측안전지수", fontsize=20)    
    fig.savefig(os.path.join(STATIC_DIR,'images/21030.png'),dpi=600)
    #bigdataPro.makeGraph(df.title, df.point_avg)
    plt.figure(figsize=(12,12))
    plt.barh(data3.loc[4].gu,data3.loc[4].cctv,height=0.6)
    plt.barh(data8.loc[0].score,data8.loc[0].cctv,height=0.6)
    #plt.xlabel("")
    #plt.ylabel("")
    plt.title("testfile", fontsize=20)
    plt.savefig(os.path.join(STATIC_DIR,'images/21030_2.png'),dpi=600)
    
    return render(request,'gu/gu_21030.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})

def gu_21040(request): #영도구
    data=list(Data.objects.values('num').filter(gu_id='21040',type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21040',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu='영도'))
    data7=list(Grade.objects.values('cctv').filter(gu='영도'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu='영도'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    
    fig, ax = plt.subplots(2, 1, figsize=(12,12))
    ax[0].scatter(data3.gu, data3.grade, marker='o', label='안전등급', c='black')
    ax[0].set_yticks([1,2,3,4,5])
    ax[0].set_title('예측안전등급', fontsize=20)
    ax[0].invert_yaxis()
    ax[0].scatter('영도',data3.loc[13].grade,c='magenta',s=350)
    
    ax[1].bar(data3.gu,data3.score)
    ax[1].set_title("예측안전지수", fontsize=20)    
    fig.savefig(os.path.join(STATIC_DIR,'images/21040.png'),dpi=600)
    #bigdataPro.makeGraph(df.title, df.point_avg)
    plt.figure(figsize=(12,12))
    plt.barh(data3.loc[13].gu,data3.loc[13].cctv,height=0.6)
    plt.barh(data8.loc[0].score,data8.loc[0].cctv,height=0.6)
    #plt.xlabel("")
    #plt.ylabel("")
    plt.title("testfile", fontsize=20)
    plt.savefig(os.path.join(STATIC_DIR,'images/21040_2.png'),dpi=600)
    
    return render(request,'gu/gu_21040.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})

def gu_21050(request): #부산진
    data=list(Data.objects.values('num').filter(gu_id='21050',type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21050',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu='부산진'))
    data7=list(Grade.objects.values('cctv').filter(gu='부산진'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu='부산진'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    
    fig, ax = plt.subplots(2, 1, figsize=(12,12))
    ax[0].scatter(data3.gu, data3.grade, marker='o', label='안전등급', c='black')
    ax[0].set_yticks([1,2,3,4,5])
    ax[0].set_title('예측안전등급', fontsize=20)
    ax[0].invert_yaxis()
    ax[0].scatter('부산진',data3.loc[6].grade,c='magenta',s=350)
    
    ax[1].bar(data3.gu,data3.score)
    ax[1].set_title("예측안전지수", fontsize=20)    
    fig.savefig(os.path.join(STATIC_DIR,'images/21050.png'),dpi=600)
    #bigdataPro.makeGraph(df.title, df.point_avg)
    plt.figure(figsize=(12,12))
    plt.barh(data3.loc[6].gu,data3.loc[6].cctv,height=0.6)
    plt.barh(data8.loc[0].score,data8.loc[0].cctv,height=0.6)
    #plt.xlabel("")
    #plt.ylabel("")
    plt.title("testfile", fontsize=20)
    plt.savefig(os.path.join(STATIC_DIR,'images/21050_2.png'),dpi=600)
    
    return render(request,'gu/gu_21050.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})

def gu_21060(request): #동래
    data=list(Data.objects.values('num').filter(gu_id='21060',type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21060',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu='동래'))
    data7=list(Grade.objects.values('cctv').filter(gu='동래'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu='동래'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    
    fig, ax = plt.subplots(2, 1, figsize=(12,12))
    ax[0].scatter(data3.gu, data3.grade, marker='o', label='안전등급', c='black')
    ax[0].set_yticks([1,2,3,4,5])
    ax[0].set_title('예측안전등급', fontsize=20)
    ax[0].invert_yaxis()
    ax[0].scatter('동래',data3.loc[5].grade,c='magenta',s=350)
    
    ax[1].bar(data3.gu,data3.score)
    ax[1].set_title("예측안전지수", fontsize=20)    
    fig.savefig(os.path.join(STATIC_DIR,'images/21060.png'),dpi=600)
    #bigdataPro.makeGraph(df.title, df.point_avg)
    plt.figure(figsize=(12,12))
    plt.barh(data3.loc[5].gu,data3.loc[5].cctv,height=0.6)
    plt.barh(data8.loc[0].score,data8.loc[0].cctv,height=0.6)
    #plt.xlabel("")
    #plt.ylabel("")
    plt.title("testfile", fontsize=20)
    plt.savefig(os.path.join(STATIC_DIR,'images/21060_2.png'),dpi=600)
    
    return render(request,'gu/gu_21060.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})

def gu_21070(request): #남구
    data=list(Data.objects.values('num').filter(gu_id='21070',type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21070',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu='남구'))
    data7=list(Grade.objects.values('cctv').filter(gu='남구'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu='남구'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    
    fig, ax = plt.subplots(2, 1, figsize=(12,12))
    ax[0].scatter(data3.gu, data3.grade, marker='o', label='안전등급', c='black')
    ax[0].set_yticks([1,2,3,4,5])
    ax[0].set_title('예측안전등급', fontsize=20)
    ax[0].invert_yaxis()
    ax[0].scatter('남구',data3.loc[3].grade,c='magenta',s=350)
    
    ax[1].bar(data3.gu,data3.score)
    ax[1].set_title("예측안전지수", fontsize=20)    
    fig.savefig(os.path.join(STATIC_DIR,'images/21070.png'),dpi=600)
    #bigdataPro.makeGraph(df.title, df.point_avg)
    plt.figure(figsize=(12,12))
    plt.barh(data3.loc[3].gu,data3.loc[3].cctv,height=0.6)
    plt.barh(data8.loc[0].score,data8.loc[0].cctv,height=0.6)
    #plt.xlabel("")
    #plt.ylabel("")
    plt.title("testfile", fontsize=20)
    plt.savefig(os.path.join(STATIC_DIR,'images/21070_2.png'),dpi=600)
    
    return render(request,'gu/gu_21070.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})

def gu_21080(request): #북구
    data=list(Data.objects.values('num').filter(gu_id='21080',type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21080',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu='북구'))
    data7=list(Grade.objects.values('cctv').filter(gu='북구'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu='북구'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    
    fig, ax = plt.subplots(2, 1, figsize=(12,12))
    ax[0].scatter(data3.gu, data3.grade, marker='o', label='안전등급', c='black')
    ax[0].set_yticks([1,2,3,4,5])
    ax[0].set_title('예측안전등급', fontsize=20)
    ax[0].invert_yaxis()
    ax[0].scatter('북구',data3.loc[7].grade,c='magenta',s=350)
    
    ax[1].bar(data3.gu,data3.score)
    ax[1].set_title("예측안전지수", fontsize=20)    
    fig.savefig(os.path.join(STATIC_DIR,'images/21080.png'),dpi=600)
    #bigdataPro.makeGraph(df.title, df.point_avg)
    plt.figure(figsize=(12,12))
    plt.barh(data3.loc[7].gu,data3.loc[7].cctv,height=0.6)
    plt.barh(data8.loc[0].score,data8.loc[0].cctv,height=0.6)
    #plt.xlabel("")
    #plt.ylabel("")
    plt.title("testfile", fontsize=20)
    plt.savefig(os.path.join(STATIC_DIR,'images/21080_2.png'),dpi=600)
    
    return render(request,'gu/gu_21080.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})

def gu_21090(request): #해운대
    data=list(Data.objects.values('num').filter(gu_id='21090',type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21090',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu='해운대'))
    data7=list(Grade.objects.values('cctv').filter(gu='해운대'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu='해운대'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    
    fig, ax = plt.subplots(2, 1, figsize=(12,12))
    ax[0].scatter(data3.gu, data3.grade, marker='o', label='안전등급', c='black')
    ax[0].set_yticks([1,2,3,4,5])
    ax[0].set_title('예측안전등급', fontsize=20)
    ax[0].invert_yaxis()
    ax[0].scatter('해운대',data3.loc[15].grade,c='magenta',s=350)
    
    ax[1].bar(data3.gu,data3.score)
    ax[1].set_title("예측안전지수", fontsize=20)    
    fig.savefig(os.path.join(STATIC_DIR,'images/21090.png'),dpi=600)
    #bigdataPro.makeGraph(df.title, df.point_avg)
    plt.figure(figsize=(12,12))
    plt.barh(data3.loc[15].gu,data3.loc[15].cctv,height=0.6)
    plt.barh(data8.loc[0].score,data8.loc[0].cctv,height=0.6)
    #plt.xlabel("")
    #plt.ylabel("")
    plt.title("testfile", fontsize=20)
    plt.savefig(os.path.join(STATIC_DIR,'images/21090_2.png'),dpi=600)
    
    return render(request,'gu/gu_21090.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})

def gu_21100(request): #사하
    data=list(Data.objects.values('num').filter(gu_id='21100',type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21100',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu='사하'))
    data7=list(Grade.objects.values('cctv').filter(gu='사하'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu='사하'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    
    fig, ax = plt.subplots(2, 1, figsize=(12,12))
    ax[0].scatter(data3.gu, data3.grade, marker='o', label='안전등급', c='black')
    ax[0].set_yticks([1,2,3,4,5])
    ax[0].set_title('예측안전등급', fontsize=20)
    ax[0].invert_yaxis()
    ax[0].scatter('사하',data3.loc[9].grade,c='magenta',s=350)
    
    ax[1].bar(data3.gu,data3.score)
    ax[1].set_title("예측안전지수", fontsize=20)    
    fig.savefig(os.path.join(STATIC_DIR,'images/21100.png'),dpi=600)
    #bigdataPro.makeGraph(df.title, df.point_avg)
    plt.figure(figsize=(12,12))
    plt.barh(data3.loc[9].gu,data3.loc[9].cctv,height=0.6)
    plt.barh(data8.loc[0].score,data8.loc[0].cctv,height=0.6)
    #plt.xlabel("")
    #plt.ylabel("")
    plt.title("testfile", fontsize=20)
    plt.savefig(os.path.join(STATIC_DIR,'images/21100_2.png'),dpi=600)
    
    return render(request,'gu/gu_21100.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})

def gu_21110(request): #금정
    data=list(Data.objects.values('num').filter(gu_id='21110',type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21110',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu='금정'))
    data7=list(Grade.objects.values('cctv').filter(gu='금정'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu='금정'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    
    fig, ax = plt.subplots(2, 1, figsize=(12,12))
    ax[0].scatter(data3.gu, data3.grade, marker='o', label='안전등급', c='black')
    ax[0].set_yticks([1,2,3,4,5])
    ax[0].set_title('예측안전등급', fontsize=20)
    ax[0].invert_yaxis()
    ax[0].scatter('금정',data3.loc[1].grade,c='magenta',s=350)
    
    ax[1].bar(data3.gu,data3.score)
    ax[1].set_title("예측안전지수", fontsize=20)    
    fig.savefig(os.path.join(STATIC_DIR,'images/21110.png'),dpi=600)
    #bigdataPro.makeGraph(df.title, df.point_avg)
    plt.figure(figsize=(12,12))
    plt.barh(data3.loc[1].gu,data3.loc[1].cctv,height=0.6)
    plt.barh(data8.loc[0].score,data8.loc[0].cctv,height=0.6)
    #plt.xlabel("")
    #plt.ylabel("")
    plt.title("testfile", fontsize=20)
    plt.savefig(os.path.join(STATIC_DIR,'images/21110_2.png'),dpi=600)
    
    return render(request,'gu/gu_21110.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})

def gu_21120(request): #강서
    data=list(Data.objects.values('num').filter(gu_id='21120',type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21120',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu='강서'))
    data7=list(Grade.objects.values('cctv').filter(gu='강서'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu='강서'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    
    fig, ax = plt.subplots(2, 1, figsize=(12,12))
    ax[0].scatter(data3.gu, data3.grade, marker='o', label='안전등급', c='black')
    ax[0].set_yticks([1,2,3,4,5])
    ax[0].set_title('예측안전등급', fontsize=20)
    ax[0].invert_yaxis()
    ax[0].scatter('강서',data3.loc[0].grade,c='magenta',s=350)
    
    ax[1].bar(data3.gu,data3.score)
    ax[1].set_title("예측안전지수", fontsize=20)    
    fig.savefig(os.path.join(STATIC_DIR,'images/21120.png'),dpi=600)
    #bigdataPro.makeGraph(df.title, df.point_avg)
    plt.figure(figsize=(12,12))
    plt.barh(data3.loc[0].gu,data3.loc[0].cctv,height=0.6)
    plt.barh(data8.loc[0].score,data8.loc[0].cctv,height=0.6)
    #plt.xlabel("")
    #plt.ylabel("")
    plt.title("testfile", fontsize=20)
    plt.savefig(os.path.join(STATIC_DIR,'images/21120_2.png'),dpi=600)
    
    return render(request,'gu/gu_21120.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})

def gu_21130(request): #연제
    data=list(Data.objects.values('num').filter(gu_id='21130',type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21130',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu='연제'))
    data7=list(Grade.objects.values('cctv').filter(gu='연제'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu='연제'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    
    fig, ax = plt.subplots(2, 1, figsize=(12,12))
    ax[0].scatter(data3.gu, data3.grade, marker='o', label='안전등급', c='black')
    ax[0].set_yticks([1,2,3,4,5])
    ax[0].set_title('예측안전등급', fontsize=20)
    ax[0].invert_yaxis()
    ax[0].scatter('연제',data3.loc[12].grade,c='magenta',s=350)
    
    ax[1].bar(data3.gu,data3.score)
    ax[1].set_title("예측안전지수", fontsize=20)    
    fig.savefig(os.path.join(STATIC_DIR,'images/21130.png'),dpi=600)
    #bigdataPro.makeGraph(df.title, df.point_avg)
    plt.figure(figsize=(12,12))
    plt.barh(data3.loc[12].gu,data3.loc[12].cctv,height=0.6)
    plt.barh(data8.loc[0].score,data8.loc[0].cctv,height=0.6)
    #plt.xlabel("")
    #plt.ylabel("")
    plt.title("testfile", fontsize=20)
    plt.savefig(os.path.join(STATIC_DIR,'images/21130_2.png'),dpi=600)
    
    return render(request,'gu/gu_21130.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})

def gu_21140(request): #수영
    data=list(Data.objects.values('num').filter(gu_id='21140',type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21140',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu='수영'))
    data7=list(Grade.objects.values('cctv').filter(gu='수영'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu='수영'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    
    fig, ax = plt.subplots(2, 1, figsize=(12,12))
    ax[0].scatter(data3.gu, data3.grade, marker='o', label='안전등급', c='black')
    ax[0].set_yticks([1,2,3,4,5])
    ax[0].set_title('예측안전등급', fontsize=20)
    ax[0].invert_yaxis()
    ax[0].scatter('수영',data3.loc[11].grade,c='magenta',s=350)
    
    ax[1].bar(data3.gu,data3.score)
    ax[1].set_title("예측안전지수", fontsize=20)    
    fig.savefig(os.path.join(STATIC_DIR,'images/21140.png'),dpi=600)
    #bigdataPro.makeGraph(df.title, df.point_avg)
    plt.figure(figsize=(12,12))
    plt.barh(data3.loc[11].gu,data3.loc[11].cctv,height=0.6)
    plt.barh(data8.loc[0].score,data8.loc[0].cctv,height=0.6)
    #plt.xlabel("")
    #plt.ylabel("")
    plt.title("testfile", fontsize=20)
    plt.savefig(os.path.join(STATIC_DIR,'images/21140_2.png'),dpi=600)
    
    return render(request,'gu/gu_21140.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})

def gu_21150(request): #사상
    data=list(Data.objects.values('num').filter(gu_id='21150',type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21150',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu='사상'))
    data7=list(Grade.objects.values('cctv').filter(gu='사상'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu='사상'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    
    fig, ax = plt.subplots(2, 1, figsize=(12,12))
    ax[0].scatter(data3.gu, data3.grade, marker='o', label='안전등급', c='black')
    ax[0].set_yticks([1,2,3,4,5])
    ax[0].set_title('예측안전등급', fontsize=20)
    ax[0].invert_yaxis()
    ax[0].scatter('사상',data3.loc[8].grade,c='magenta',s=350)
    
    ax[1].bar(data3.gu,data3.score)
    ax[1].set_title("예측안전지수", fontsize=20)    
    fig.savefig(os.path.join(STATIC_DIR,'images/21150.png'),dpi=600)
    #bigdataPro.makeGraph(df.title, df.point_avg)
    plt.figure(figsize=(12,12))
    plt.barh(data3.loc[8].gu,data3.loc[8].cctv,height=0.6)
    plt.barh(data8.loc[0].score,data8.loc[0].cctv,height=0.6)
    #plt.xlabel("")
    #plt.ylabel("")
    plt.title("testfile", fontsize=20)
    plt.savefig(os.path.join(STATIC_DIR,'images/21150_2.png'),dpi=600)
    
    return render(request,'gu/gu_21150.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})

def gu_21310(request): #기장
    data=list(Data.objects.values('num').filter(gu_id='21310',type_id='d14'))
    data2=list(Data.objects.values('num').annotate().filter(gu_id='21310',type_id='d15'))
    engine=create_engine('mysql+pymysql://hj:pass1234@localhost/bdpj',convert_unicode=True)
    conn=engine.connect()
    data3=pd.read_sql_table('board_grade',conn)
    data4=list(Average.objects.values('crime').filter(score='1'))
    data5=list(Average.objects.values('cctv').filter(score='1'))
    data6=list(Grade.objects.values('crime').filter(gu='기장'))
    data7=list(Grade.objects.values('cctv').filter(gu='기장'))
    data8=pd.read_sql_table('board_average',conn)
    data9=list(Average.objects.values('cctv2').filter(score='1'))
    data10=list(Grade.objects.values('cctv2').filter(gu='기장'))
    #data4=pd.read_sql_table('project_average',conn)
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=font_location).get_name()
    matplotlib.rc('font', family=font_name)
    
    fig, ax = plt.subplots(2, 1, figsize=(12,12))
    ax[0].scatter(data3.gu, data3.grade, marker='o', label='안전등급', c='black')
    ax[0].set_yticks([1,2,3,4,5])
    ax[0].set_title('예측안전등급', fontsize=20)
    ax[0].invert_yaxis()
    ax[0].scatter('기장',data3.loc[2].grade,c='magenta',s=350)
    
    ax[1].bar(data3.gu,data3.score)
    ax[1].set_title("예측안전지수", fontsize=20)    
    fig.savefig(os.path.join(STATIC_DIR,'images/21310.png'),dpi=600)
    #bigdataPro.makeGraph(df.title, df.point_avg)
    plt.figure(figsize=(12,12))
    plt.barh(data3.loc[2].gu,data3.loc[2].cctv,height=0.6)
    plt.barh(data8.loc[0].score,data8.loc[0].cctv,height=0.6)
    #plt.xlabel("")
    #plt.ylabel("")
    plt.title("testfile", fontsize=20)
    plt.savefig(os.path.join(STATIC_DIR,'images/21310_2.png'),dpi=600)
    
    return render(request,'gu/gu_21310.html',{'scores':data,'grade':data2,'crime':data4,'cctv':data5,'grade_crime':data6,'grade_cctv':data7,'grade_cctv2':data9,'cctv2':data10})



            
        
