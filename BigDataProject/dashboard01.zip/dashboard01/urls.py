"""dashboard01 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from board import views, gu_grade

urlpatterns = [
    
    path('',views.main),
    path('admin/', admin.site.urls), #admin 하면 들어가는게 이거때문임
        #장고는 기본적으로 만들어져있음
    
    path('list/',views.list),
    # path('cctv_map/',views.cctv_map),
    path('map/',views.map),
    path('db',views.db),
    #path('result/',views.result),
    path('result/',gu_grade.result),
    
    
    path('gu_insert/',views.gu_insert),
    path('type_insert/',views.type_insert),
    path('cctv_insert/',views.cctv_insert),
    path('securitylight_insert/',views.securitylight_insert),
    path('bell_insert/',views.bell_insert),
    path('bar_insert/',views.bar_insert),
    path('police_station_insert/',views.police_station_insert),
    path('data2019_insert/',views.data2019_insert), 
    path('cctv_map/',views.cctv_map),
    path('grade_insert/',views.grade_insert),
    path('average_insert/',views.average_insert),
    
    path('test/',views.test),
    path('test/gu_21010/',gu_grade.gu_21010),
    path('test/gu_21020/',gu_grade.gu_21020),
    path('test/gu_21030/',gu_grade.gu_21030),
    path('test/gu_21040/',gu_grade.gu_21040),
    path('test/gu_21050/',gu_grade.gu_21050),
    path('test/gu_21060/',gu_grade.gu_21060),
    path('test/gu_21070/',gu_grade.gu_21070),
    path('test/gu_21080/',gu_grade.gu_21080),
    path('test/gu_21090/',gu_grade.gu_21090),
    path('test/gu_21100/',gu_grade.gu_21100),
    path('test/gu_21110/',gu_grade.gu_21110),
    path('test/gu_21120/',gu_grade.gu_21120),
    path('test/gu_21130/',gu_grade.gu_21130),
    path('test/gu_21140/',gu_grade.gu_21140),
    path('test/gu_21150/',gu_grade.gu_21150),
    path('test/gu_21310/',gu_grade.gu_21310),
    
    
    
    
]
