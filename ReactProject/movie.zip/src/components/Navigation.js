import React from "react";
import { Link } from "react-router-dom";
import "./Navigation.css";

function Navigation(){
    return(
        <div className="nav">
            <Link to ="/">Home</Link>
            <Link to ="/movie">영화!</Link>
            <Link to ="/shop">쇼핑!</Link>
            <Link to ="/blog">블로그!</Link> 
        </div>
    );
}

export default Navigation;