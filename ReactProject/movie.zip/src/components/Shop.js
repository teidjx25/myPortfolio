import React from "react";
import propTypes from "prop-types";
import './Shop.css';


function Shop({Link, title, image, lprice, hprice}){ //새로운 컴퍼넌트 호출하려면 이 컴퍼넌트안에서 호출을 시키면 같이 호출이 됨
    return (
        <div className="shop">
            
            <a href={Link} target="blank">
                <img src={image} alt={title} titlt={title}></img>
                  
                <div className="shop__data">
                    <h3 className="shop__title">{
                        title.replace(/<b>/gi,"").replace(/<\/b>/gi,"")
                    }</h3>

                    <p className="shop__price">
                        <span>최저가 : </span> {lprice}원 ~ <span>최고가 : </span> {hprice}원
                    </p>
                </div>
        </a>
      </div>
      )
    };




Shop.propTypes = {
  id: propTypes.string.isRequired,
  title: propTypes.string.isRequired,
  image: propTypes.string.isRequired,
  lprice: propTypes.string.isRequired,
  hprice: propTypes.string.isRequired,
};

export default Shop;