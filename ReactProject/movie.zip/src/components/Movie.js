import React from "react";
import propTypes from "prop-types";
import './Movie.css';
function Movie({id, year, title, poster, rating, director, actor}){ //새로운 컴퍼넌트 호출하려면 이 컴퍼넌트안에서 호출을 시키면 같이 호출이 됨
    return (
        <div className="movie">
        <a href={id} target="blank">
          <img src={poster} alt={title} titlt={title}></img>
        <div className="movie__data">
          <h3 className="movie__title">{
              title.replace(/<b>/gi,"").replace(/<\/b>/gi,"")
            }</h3>
          <p className="movie__rating">
            <span>평점</span> {rating}/10
          </p>
          <p className="movie__year">
            <span>개봉일</span> {year}
          </p>
        <p className="movie__director">
          <span>감독</span> {director}
        </p>
        <p className="movie__actor">
          <span>배우</span> {actor}
        </p>
        </div>
      </a>
      </div>
      )
    };

Movie.propTypes = {
  id: propTypes.string.isRequired,
  year: propTypes.string.isRequired,
  title: propTypes.string.isRequired,
  poster: propTypes.string.isRequired,
  rating: propTypes.string.isRequired,
  director: propTypes.string.isRequired,
  actor: propTypes.string.isRequired

};

export default Movie;