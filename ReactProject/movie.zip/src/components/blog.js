import React from "react";
import propTypes from "prop-types";
import './Blog.css';


function Blog({Link, title, Bloggername, description}){ //새로운 컴퍼넌트 호출하려면 이 컴퍼넌트안에서 호출을 시키면 같이 호출이 됨
    return (
        <div className="Bloging">
            
            <a href={Link} target="blank">  
                <div className="Bloging__data">
                    <h3 className="Bloging__title">{
                        title.replace(/<b>/gi,"").replace(/<\/b>/gi,"")
                    }</h3>
                    <h3 className="Bloging__name">{Bloggername}</h3>
                    <p>
                       {description.replace(/<b>/gi,"").replace(/<\/b>/gi,"").slice(0, 180)}...
                    </p>
                </div>
        </a>
      </div>
      )
    };




Blog.propTypes = {
  title: propTypes.string.isRequired,
  Bloggername: propTypes.string.isRequired,
  description: propTypes.string.isRequired,
};

export default Blog;