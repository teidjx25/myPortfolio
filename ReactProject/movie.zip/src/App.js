import React from "react";
import {HashRouter,Route} from "react-router-dom";
import Home from "./routes/Home"
import Navigation from "./components/Navigation";
import MovieSearch from './routes/MovieSearch'
import ShopSearch from './routes/ShopSearch'
import BlogSearch from './routes/BlogSearch'

function App(){
  return (
    <HashRouter>
       <Navigation /> 
      <Route path="/" exact={true} component={Home} />
      <Route path="/movie" component={MovieSearch} /> 
      <Route path="/shop" component={ShopSearch} /> 
      <Route path="/blog" component={BlogSearch} />
    
    </HashRouter>
  );

}

export default App;




