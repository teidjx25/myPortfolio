import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import './Home.css';
class Home extends Component {

    render() {
      return (
        <div className="container">
          <header className="App-header">
             <h1> 네이버 API 연동 검색 API </h1>
              <ul>

              <Link to={{ pathname:'/movie' }}>
                <li>영화 검색 하러 가기!</li>
             </Link>

             <Link to={{ pathname:'/shop' }}>
                <li>쇼핑 하러 가기!</li>
             </Link>

             <Link to={{ pathname:'/blog' }}>
                <li>블로그 둘러 보러 가기</li>
             </Link>
              </ul>

          </header>
        </div>
      );
    }
  }

export default Home;