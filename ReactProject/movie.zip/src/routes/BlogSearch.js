    import React from "react";
    import axios from "axios";
    import Blog from "../components/blog";
    import './Home.css';
 
    class BloggingSearch extends React.Component{      //리턴하기 위해서는render() 필수
      
      state ={                              //유동적인 값 쓰기 위함 
        isLoading:true,
        Bloginf:[],
        value: ""
      };
    
      getSearchBlog = async () => {
        console.log('search Blog');
        const ID_KEY = 'lRzD4ia4onESu6wa7Nol';  //네이버에서 공급받은 id
        const SECRET_KEY = 'yCWk6TLVPC';        //네이버에서 공급받은 pass
        const search = this.state.value;
    if(search  === ""){
      this.setState({Bloginf:[], isLoading: false})
    } else {
    
       const {data:{items}} = await axios.get(`/v1/search/Blog.json?query=${search}&display=100&sort=sim`,{headers:{'X-Naver-Client-Id':ID_KEY,'X-Naver-Client-Secret':SECRET_KEY}});
       this.setState({Bloginf:items, isLoading: false})
      }
      };
    
      componentDidMount() {
        this.getSearchBlog();
      };

      handleChange = (e) => {
        console.log(e.type + ":", e.target.value);
        this.setState({
          value: e.target.value
        });
      };
    
      handleSubmit = (e) => {
        console.log(e.type + ":", this.state.value);
        e.preventDefault();
        this.getSearchBlog();
      };

      render(){
        const{isLoading,Bloginf} =this.state;
        return (
        <section className ="container">
        {isLoading?(
          <div className = "loader">
              <span className="loader__text">"Loding..."</span>
        </div>
        ): (
          <form onSubmit={this.handleSubmit}>
            <div>
              <div className="input_div">
                <h1>검색어를 입력하세요</h1>
                </div>
              <div className="input__box">
              <input className="input_search" type="text" value={this.state.value} onChange={this.handleChange} placeholder="블로그 포스트 검색" />
              <button onChange={this.handleSubmit}>검색</button>
              </div>
              <div className="Bloginf">
               {Bloginf.map((Blogging)=>{       
                      return (
                        <Blog    
                        key={Blogging.link}
                        Link={Blogging.link}
                        title={Blogging.title}
                        description={Blogging.description}
                        Bloggername={Blogging.Bloggername}
                        /> 
              );
            })}
          </div>
          </div>
        </form>
        )}
        </section>
        );
      }
    }
    
    
    export default BloggingSearch;
