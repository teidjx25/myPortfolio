    import React from "react";
    import axios from "axios";
    import Shop from "../components/Shop";
    import './Home.css';
 
    class ShopSearch extends React.Component{      //리턴하기 위해서는render() 필수
      
      state ={                              //유동적인 값 쓰기 위함 
        isLoading:true,
        shopping:[],
        value: ""
      };
    
      getSearchShop = async () => {
        console.log('search Shop');
        const ID_KEY = 'lRzD4ia4onESu6wa7Nol';  //네이버에서 공급받은 id
        const SECRET_KEY = 'yCWk6TLVPC';        //네이버에서 공급받은 pass
        const search = this.state.value;
    if(search  === ""){
      this.setState({shopping:[], isLoading: false})
    } else {
    
       const {data:{items}} = await axios.get(`/v1/search/shop.json?query=${search}&display=100&sort=sim`,{headers:{'X-Naver-Client-Id':ID_KEY,'X-Naver-Client-Secret':SECRET_KEY}});
       this.setState({shopping:items, isLoading: false})
      }
      };
    
      componentDidMount() {
        this.getSearchShop();
      };

      handleChange = (e) => {
        console.log(e.type + ":", e.target.value);
        this.setState({
          value: e.target.value
        });
      };
    
      handleSubmit = (e) => {
        console.log(e.type + ":", this.state.value);
        e.preventDefault();
        this.getSearchShop();
      };

      render(){
        const{isLoading,shopping} =this.state;
        return (
        <section className ="container">
        {isLoading?(
          <div className = "loader">
              <span className="loader__text">"Loding..."</span>
        </div>
        ): (
          <form onSubmit={this.handleSubmit}>
            <div>
              <div className="input_div">
                <h1>상품 검색</h1>
                </div>
                <div className="input__box">
              <input className="input_search" type="text" value={this.state.value} onChange={this.handleChange} placeholder="상품명을 검색" />
              <button onChange={this.handleSubmit}>검색</button>
              </div>
              <div className="shopping">
               {shopping.map((shop)=>{        //isLoading의 조건 true는 async(동기화)작업이 아직 끝나지 않음, 끝나면 shopping의 배열을 실행
                      return (
                        <Shop    
                        key={shop.link}
                        Link={shop.link}
                        title={shop.title}
                        hprice={shop.hprice}
                        lprice={shop.lprice}
                        image={shop.image}
                        /> 
          
              );
            })}
          </div>
          </div>
        </form>
        )}
        </section>
        );
      }
    }
    
    
    export default ShopSearch;
